"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.securityCheck_FilePath = exports.getID = void 0;
function getID(length) {
    var id = "";
    for (var i = 0; i < length; i++) {
        var r = Math.floor(Math.random() * 62);
        if (r < 10) {
            // 0 - 9
            id += String.fromCharCode(r + 48);
        }
        else if (r < 36) {
            // a - z
            id += String.fromCharCode(r + 97 - 10);
        }
        else {
            id += String.fromCharCode(r + 65 - 36);
        }
    }
    return id;
}
exports.getID = getID;
function securityCheck_FilePath(filepath) {
    // not allowed to refer parent path
    if (filepath.indexOf("..") >= 0) {
        console.error("[Security Error] Invalid File Path - " + filepath);
    }
}
exports.securityCheck_FilePath = securityCheck_FilePath;
//# sourceMappingURL=util.js.map