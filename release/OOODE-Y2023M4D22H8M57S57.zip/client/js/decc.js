"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __generator = (this && this.__generator) || function (thisArg, body) {
    var _ = { label: 0, sent: function() { if (t[0] & 1) throw t[1]; return t[1]; }, trys: [], ops: [] }, f, y, t, g;
    return g = { next: verb(0), "throw": verb(1), "return": verb(2) }, typeof Symbol === "function" && (g[Symbol.iterator] = function() { return this; }), g;
    function verb(n) { return function (v) { return step([n, v]); }; }
    function step(op) {
        if (f) throw new TypeError("Generator is already executing.");
        while (_) try {
            if (f = 1, y && (t = op[0] & 2 ? y["return"] : op[0] ? y["throw"] || ((t = y["return"]) && t.call(y), 0) : y.next) && !(t = t.call(y, op[1])).done) return t;
            if (y = 0, t) op = [op[0] & 2, t.value];
            switch (op[0]) {
                case 0: case 1: t = op; break;
                case 4: _.label++; return { value: op[1], done: false };
                case 5: _.label++; y = op[1]; op = [0]; continue;
                case 7: op = _.ops.pop(); _.trys.pop(); continue;
                default:
                    if (!(t = _.trys, t = t.length > 0 && t[t.length - 1]) && (op[0] === 6 || op[0] === 2)) { _ = 0; continue; }
                    if (op[0] === 3 && (!t || (op[1] > t[0] && op[1] < t[3]))) { _.label = op[1]; break; }
                    if (op[0] === 6 && _.label < t[1]) { _.label = t[1]; t = op; break; }
                    if (t && _.label < t[2]) { _.label = t[2]; _.ops.push(op); break; }
                    if (t[2]) _.ops.pop();
                    _.trys.pop(); continue;
            }
            op = body.call(thisArg, _);
        } catch (e) { op = [6, e]; y = 0; } finally { f = t = 0; }
        if (op[0] & 5) throw op[1]; return { value: op[0] ? op[1] : void 0, done: true };
    }
};
var __extends = (this && this.__extends) || (function () {
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (Object.prototype.hasOwnProperty.call(b, p)) d[p] = b[p]; };
        return extendStatics(d, b);
    };
    return function (d, b) {
        if (typeof b !== "function" && b !== null)
            throw new TypeError("Class extends value " + String(b) + " is not a constructor or null");
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
var __spreadArray = (this && this.__spreadArray) || function (to, from, pack) {
    if (pack || arguments.length === 2) for (var i = 0, l = from.length, ar; i < l; i++) {
        if (ar || !(i in from)) {
            if (!ar) ar = Array.prototype.slice.call(from, 0, i);
            ar[i] = from[i];
        }
    }
    return to.concat(ar || Array.prototype.slice.call(from));
};
var ooo;
(function (ooo) {
    var de;
    (function (de) {
        var common;
        (function (common) {
            //#region Add New Element
            /**
             * Add new HTML element.
             * @param parent Parent element of new element.
             * @param tagName tag name of new element.
             * @param className class name of new element.
             */
            function addTag(parent, tagName, className) {
                var _a;
                var doc = (_a = parent.ownerDocument) !== null && _a !== void 0 ? _a : document;
                var element = doc.createElement(tagName);
                parent.appendChild(element);
                if (className) {
                    if (Array.isArray(className)) {
                        for (var _i = 0, className_1 = className; _i < className_1.length; _i++) {
                            var classNameItem = className_1[_i];
                            element.classList.add(classNameItem);
                        }
                    }
                    else {
                        element.classList.add(className);
                    }
                }
                return element;
            }
            common.addTag = addTag;
            function addTextDiv(parent, text, className) {
                var div = addTag(parent, "div", className);
                div.innerText = text;
                return div;
            }
            common.addTextDiv = addTextDiv;
            /**
             * Insert new HTML element.
             * @param target Target element of new element. New element is insert before this.
             * @param tagName tag name of new element.
             * @param className class name of new element.
             */
            function insertTagBefore(target, tagName, className) {
                var _a;
                var doc = (_a = target.ownerDocument) !== null && _a !== void 0 ? _a : document;
                var parent = target.parentElement;
                var element = doc.createElement(tagName);
                parent === null || parent === void 0 ? void 0 : parent.insertBefore(element, target);
                if (className) {
                    if (Array.isArray(className)) {
                        for (var _i = 0, className_2 = className; _i < className_2.length; _i++) {
                            var classNameItem = className_2[_i];
                            element.classList.add(classNameItem);
                        }
                    }
                    else {
                        element.classList.add(className);
                    }
                }
                return element;
            }
            common.insertTagBefore = insertTagBefore;
            /**
             * Insert new HTML element.
             * @param target Target element of new element. New element is insert after this.
             * @param tagName tag name of new element.
             * @param className class name of new element.
             */
            function insertTagAfter(target, tagName, className) {
                var _a;
                var doc = (_a = target.ownerDocument) !== null && _a !== void 0 ? _a : document;
                var parent = target.parentElement;
                var element = doc.createElement(tagName);
                parent === null || parent === void 0 ? void 0 : parent.insertBefore(element, target.nextSibling);
                if (className) {
                    if (Array.isArray(className)) {
                        for (var _i = 0, className_3 = className; _i < className_3.length; _i++) {
                            var classNameItem = className_3[_i];
                            element.classList.add(classNameItem);
                        }
                    }
                    else {
                        element.classList.add(className);
                    }
                }
                return element;
            }
            common.insertTagAfter = insertTagAfter;
            /**
             * Add new button.
             * @param parent Parent element of new button
             * @param caption Caption of new button
             * @param callback Callback function when the button is clicked
             * @param className class name of new button.
             */
            function addButton(parent, caption, callback, className) {
                var button = addTag(parent, "button", className);
                button.addEventListener("click", callback);
                button.innerHTML = caption;
                return button;
            }
            common.addButton = addButton;
            function addImageButton(parent, image, callback, className) {
                var button = addTag(parent, "button", className);
                button.addEventListener("click", callback);
                var imageTag = addTag(button, "img");
                imageTag.src = image;
                return button;
            }
            common.addImageButton = addImageButton;
            function addTR(parent, columns, trClassName, tdClassName) {
                var tr = addTag(parent, "tr", trClassName);
                var tds = [];
                for (var i = 0; i < columns; i++) {
                    tds.push(addTag(tr, "td", tdClassName));
                }
                return [tr, tds];
            }
            common.addTR = addTR;
            var scrollWidth = 40;
            var TabView = /** @class */ (function () {
                function TabView(parent, tabItemInfoList) {
                    var _this = this;
                    this.parent = parent;
                    this.items = [];
                    parent.classList.add("pane-tab");
                    var headAreaTop = addTag(parent, "div", "head-area");
                    this.headAreaScroll = addTag(headAreaTop, "div", "head-area-scroll");
                    this.headArea = addTag(this.headAreaScroll, "div", "head-area-items");
                    this.bodyArea = addTag(parent, "div", "body-area");
                    addImageButton(headAreaTop, "../image/leftArrow.svg", function () {
                        _this.headAreaScroll.scrollBy({
                            left: -scrollWidth
                        });
                    }, ["tab-button", "left"]);
                    addImageButton(headAreaTop, "../image/rightArrow.svg", function () {
                        _this.headAreaScroll.scrollBy({
                            left: scrollWidth
                        });
                    }, ["tab-button", "right"]);
                    for (var _i = 0, tabItemInfoList_1 = tabItemInfoList; _i < tabItemInfoList_1.length; _i++) {
                        var tabItemInfo = tabItemInfoList_1[_i];
                        this.addTabItem(tabItemInfo);
                    }
                    if (tabItemInfoList.length > 0) {
                        this.activateTabItem(tabItemInfoList[0].name, false);
                    }
                    this.adjustHeaderSize();
                }
                TabView.prototype.addTabItem = function (tabItemInfo) {
                    var _this = this;
                    // add header
                    var header = addTag(this.headArea, "span", "tab-head-item");
                    header.innerHTML = tabItemInfo.caption;
                    // add body
                    var body = addTag(this.bodyArea, "div", "tab-item");
                    if (tabItemInfo.htmlID) {
                        body.id = tabItemInfo.htmlID;
                    }
                    // click event
                    header.addEventListener("click", function () {
                        _this.activateTabItem(tabItemInfo.name);
                    });
                    // add tab item
                    this.items.push({
                        name: tabItemInfo.name,
                        header: header,
                        body: body
                    });
                };
                TabView.prototype.getTabItem = function (name) {
                    var _a;
                    return (_a = this.items.find(function (v) { return v.name == name; })) === null || _a === void 0 ? void 0 : _a.body;
                };
                TabView.prototype.activateTabItem = function (name, adjust) {
                    if (adjust === void 0) { adjust = true; }
                    for (var _i = 0, _a = this.items; _i < _a.length; _i++) {
                        var item = _a[_i];
                        if (item.name == name) {
                            item.header.classList.add("active");
                            item.body.classList.add("active");
                        }
                        else {
                            item.header.classList.remove("active");
                            item.body.classList.remove("active");
                        }
                    }
                    if (adjust) {
                        this.adjustHeaderSize();
                    }
                };
                TabView.prototype.adjustHeaderSize = function () {
                    this.headArea.style.width = this.items.reduce(function (p, v) { return p + v.header.offsetWidth; }, 5) + "px";
                };
                return TabView;
            }());
            common.TabView = TabView;
            //#endregion
            //#region Others
            function checkIsChild(parent, child) {
                var cursor = child;
                while (cursor) {
                    if (parent == cursor) {
                        return true;
                    }
                    cursor = cursor.parentNode;
                }
                return false;
            }
            common.checkIsChild = checkIsChild;
            function modal() {
                var back = common.addTag(document.body, "div");
                var base = common.addTag(back, "div");
                back.classList.add("back");
                base.classList.add("base");
                back.addEventListener("click", function (ev) {
                    if (ev.target == back) {
                        back.remove();
                    }
                });
                return [base, back];
            }
            common.modal = modal;
            function newID() {
                for (var i = 1; true; i++) {
                    var element_1 = document.querySelector("*[data-deid='#".concat(i, "']"));
                    if (element_1 == null) {
                        return "#".concat(i);
                    }
                }
            }
            common.newID = newID;
            function objectToDataset(element, properties) {
                for (var key in properties) {
                    element.dataset["de_" + key] = properties[key];
                }
            }
            common.objectToDataset = objectToDataset;
            function datasetToObject(element, properties) {
                var _a;
                for (var key in element.dataset) {
                    if (key.startsWith("de_")) {
                        var key2 = key.substring(3);
                        properties[key2] = (_a = element.dataset[key]) !== null && _a !== void 0 ? _a : "";
                    }
                }
            }
            common.datasetToObject = datasetToObject;
            function isChildOf(c, p) {
                var cur = c.parentNode;
                while (cur != null) {
                    if (cur == p) {
                        return true;
                    }
                    cur = cur.parentNode;
                }
                return false;
            }
            common.isChildOf = isChildOf;
            //#endregion
        })(common = de.common || (de.common = {}));
    })(de = ooo.de || (ooo.de = {}));
})(ooo || (ooo = {}));
var ooo;
(function (ooo) {
    var de;
    (function (de) {
        var common;
        (function (common) {
            common.HH_CT_JSON = { "Content-Type": "application/json" };
            common.HH_CT_HTML = { "Content-Type": "text/html; charset=UTF-8" };
            common.HH_CT_TEXT = { "Content-Type": "text/plain; charset=UTF-8" };
            function post(url, data, headers) {
                return new Promise(function (res, rej) {
                    var xhr = new XMLHttpRequest();
                    xhr.open("POST", url);
                    xhr.addEventListener("load", function () {
                        if (xhr.status == 200) {
                            res(xhr.responseText);
                        }
                        else {
                            console.error(url);
                            rej(xhr);
                        }
                    });
                    xhr.addEventListener("error", function (err) {
                        console.error(url);
                        rej(err);
                    });
                    if (headers) {
                        for (var key in headers) {
                            xhr.setRequestHeader(key, headers[key]);
                        }
                    }
                    xhr.send(data !== null && data !== void 0 ? data : undefined);
                });
            }
            common.post = post;
            function postJson(url, data, headers) {
                return __awaiter(this, void 0, void 0, function () {
                    var _a, _b;
                    return __generator(this, function (_c) {
                        switch (_c.label) {
                            case 0:
                                _b = (_a = JSON).parse;
                                return [4 /*yield*/, post(url, data, headers)];
                            case 1: return [2 /*return*/, _b.apply(_a, [_c.sent()])];
                        }
                    });
                });
            }
            common.postJson = postJson;
            common.COMMAND_PATH = "../../command";
        })(common = de.common || (de.common = {}));
    })(de = ooo.de || (ooo.de = {}));
})(ooo || (ooo = {}));
var ooo;
(function (ooo) {
    var de;
    (function (de) {
        var common;
        (function (common) {
            function ArrayBufferToString(array) {
                var bytes = new Uint8Array(array);
                var base64 = "";
                for (var i = 0; i < bytes.length; i++) {
                    base64 += String.fromCharCode(bytes[i]);
                }
                return base64;
            }
            common.ArrayBufferToString = ArrayBufferToString;
            function StringToArrayBuffer(binary_string) {
                var length = binary_string.length;
                var bytes = new Uint8Array(length);
                for (var i = 0; i < length; i++) {
                    bytes[i] = binary_string.charCodeAt(i);
                }
                return bytes.buffer;
            }
            common.StringToArrayBuffer = StringToArrayBuffer;
            function ArrayBufferToBase64(array) {
                return btoa(ArrayBufferToString(array));
            }
            common.ArrayBufferToBase64 = ArrayBufferToBase64;
            function Base64ToArrayBuffer(base64) {
                return StringToArrayBuffer(atob(base64));
            }
            common.Base64ToArrayBuffer = Base64ToArrayBuffer;
        })(common = de.common || (de.common = {}));
    })(de = ooo.de || (ooo.de = {}));
})(ooo || (ooo = {}));
var ooo;
(function (ooo) {
    var de;
    (function (de) {
        var element;
        (function (element_2) {
            var DEEElementBase = /** @class */ (function () {
                function DEEElementBase(factory, element) {
                    this.factory = factory;
                    this.element = element;
                    this.id = "";
                    this.name = "";
                    this.properties = {};
                    DEEElementBase.elementList.push(this);
                    de.common.datasetToObject(element, this.properties);
                }
                DEEElementBase.prototype.objectToDataset = function () {
                    if (this.element) {
                        de.common.objectToDataset(this.element, this.properties);
                    }
                };
                DEEElementBase.prototype.getSchema = function (schema) { };
                DEEElementBase.prototype.onAfterCreate = function () { };
                DEEElementBase.elementList = [];
                return DEEElementBase;
            }());
            element_2.DEEElementBase = DEEElementBase;
            var DEEFactroyBase = /** @class */ (function () {
                function DEEFactroyBase() {
                }
                //#region General Function
                DEEFactroyBase.prototype.newError = function (code) {
                    return new DEEError(this.constructor.name, code);
                };
                //#endregion
                //#region Common function for "createElement".
                DEEFactroyBase.prototype.createSimpleElement = function (range, create) {
                    var _a, _b, _c, _d, _e, _f;
                    // Check the range condition
                    if (range.startContainer == range.endContainer) {
                        if (range.startContainer.nodeType == Node.TEXT_NODE) {
                            var target = range.startContainer;
                            var parent_1 = target.parentNode;
                            var doc = target.ownerDocument;
                            var value = (_b = (_a = target.textContent) === null || _a === void 0 ? void 0 : _a.substring(range.startOffset, range.endOffset)) !== null && _b !== void 0 ? _b : "";
                            var element_3 = create(value, doc);
                            var start = range.startOffset;
                            var end = range.endOffset;
                            parent_1.insertBefore(doc.createTextNode((_d = (_c = target.textContent) === null || _c === void 0 ? void 0 : _c.substring(0, start)) !== null && _d !== void 0 ? _d : ""), target);
                            parent_1.insertBefore(element_3, target);
                            parent_1.insertBefore(doc.createTextNode((_f = (_e = target.textContent) === null || _e === void 0 ? void 0 : _e.substring(end)) !== null && _f !== void 0 ? _f : ""), target);
                            parent_1.removeChild(target);
                            return {
                                value: value,
                                element: element_3
                            };
                        }
                        else {
                            var parent_2 = range.startContainer;
                            var doc = parent_2.ownerDocument;
                            var value = "";
                            var element_4 = create(value, doc);
                            var start = range.startOffset;
                            parent_2.insertBefore(element_4, parent_2.childNodes.item(start + 1));
                            return {
                                value: value,
                                element: element_4
                            };
                        }
                    }
                    else {
                        throw this.newError("Create Error");
                    }
                };
                return DEEFactroyBase;
            }());
            element_2.DEEFactroyBase = DEEFactroyBase;
            var DEEError = /** @class */ (function () {
                function DEEError(type, code) {
                    this.type = type;
                    this.code = code;
                }
                DEEError.prototype.getMessage = function () {
                    return "[".concat(this.type, ", ").concat(this.code, "]");
                };
                return DEEError;
            }());
            element_2.DEEError = DEEError;
        })(element = de.element || (de.element = {}));
    })(de = ooo.de || (ooo.de = {}));
})(ooo || (ooo = {}));
var ooo;
(function (ooo) {
    var de;
    (function (de) {
        var element;
        (function (element_5) {
            var DeCommandButtonFactory = /** @class */ (function (_super) {
                __extends(DeCommandButtonFactory, _super);
                function DeCommandButtonFactory() {
                    return _super !== null && _super.apply(this, arguments) || this;
                }
                DeCommandButtonFactory.prototype.getType = function () { return "commandbutton"; };
                DeCommandButtonFactory.prototype.loadElement = function (element) {
                    return new DeCommandButton(this, element);
                };
                DeCommandButtonFactory.prototype.makeToolButton = function (toolbutton) {
                    toolbutton.innerHTML = "Command Button";
                };
                DeCommandButtonFactory.prototype.createElement = function (range) {
                    var valueElementPair = this.createSimpleElement(range, function (value, doc) {
                        var element = doc.createElement("button");
                        element.innerText = value || "button";
                        element.style.userSelect = "none";
                        element.contentEditable = "false";
                        return element;
                    });
                    var deButton = new DeCommandButton(this, valueElementPair.element);
                    deButton.properties.text = valueElementPair.value || "button";
                    return deButton;
                };
                return DeCommandButtonFactory;
            }(element_5.DEEFactroyBase));
            element_5.DeCommandButtonFactory = DeCommandButtonFactory;
            var DeCommandButton = /** @class */ (function (_super) {
                __extends(DeCommandButton, _super);
                function DeCommandButton() {
                    var _this = _super !== null && _super.apply(this, arguments) || this;
                    _this.propertyRoot = null;
                    return _this;
                }
                DeCommandButton.prototype.getFormData = function (data) {
                    return __awaiter(this, void 0, void 0, function () { return __generator(this, function (_a) {
                        return [2 /*return*/];
                    }); });
                };
                DeCommandButton.prototype.setFormData = function (data) { };
                DeCommandButton.prototype.deleteElement = function () {
                    throw new Error("Method not implemented.");
                };
                DeCommandButton.prototype.showProperty = function (pane) {
                    var _this = this;
                    this.propertyRoot = new element_5.DEEPropertyRoot(pane, this.properties);
                    var property = new element.DEEPropertyBox(this.propertyRoot, "Property");
                    new element.DEEPropertyItemInput(property, "text", "Caption text", "Caption text of the button.", function (v) {
                        _this.element.innerText = v;
                    });
                    new element.DEEPropertyItemSelect(property, "command", [
                        { value: "", caption: "", tooltip: "" },
                        { value: "submit", caption: "submit", tooltip: "Submit the form." },
                        { value: "clear", caption: "clear", tooltip: "Clear the form." },
                    ], "Command type", "Command type of the button.", function (v) {
                        _this.element.placeholder = v;
                    });
                    return this.propertyRoot;
                };
                DeCommandButton.prototype.setReadonly = function () {
                    this.element.setAttribute("hidden", "hidden");
                };
                DeCommandButton.prototype.onClickFormatMode = function (ev) {
                    element_5.DEEFactroyBase.onActive(this);
                };
                DeCommandButton.prototype.onClickViewMode = function (ev) {
                    command[this.properties.command]();
                };
                return DeCommandButton;
            }(element_5.DEEElementBase));
            element_5.DeCommandButton = DeCommandButton;
            var command = {
                submit: function () {
                    de.formatEditor.submit();
                },
                clear: function () {
                    de.formatEditor.clear();
                }
            };
        })(element = de.element || (de.element = {}));
    })(de = ooo.de || (ooo.de = {}));
})(ooo || (ooo = {}));
var ooo;
(function (ooo) {
    var de;
    (function (de) {
        var element;
        (function (element_6) {
            var DeDataViewFactory = /** @class */ (function (_super) {
                __extends(DeDataViewFactory, _super);
                function DeDataViewFactory() {
                    return _super !== null && _super.apply(this, arguments) || this;
                }
                DeDataViewFactory.prototype.getType = function () { return "dataview"; };
                DeDataViewFactory.prototype.loadElement = function (element) {
                    return new DeDataView(this, element, "load");
                };
                DeDataViewFactory.prototype.makeToolButton = function (toolbutton) {
                    toolbutton.innerHTML = "Data View";
                };
                DeDataViewFactory.prototype.createElement = function (range) {
                    var valueElementPair = this.createSimpleElement(range, function (value, doc) {
                        var element = doc.createElement("table");
                        element.classList.add("dataview");
                        element.contentEditable = "false";
                        return element;
                    });
                    var dee = new DeDataView(this, valueElementPair.element, "create");
                    dee.properties.default_value = valueElementPair.value;
                    return dee;
                };
                return DeDataViewFactory;
            }(element_6.DEEFactroyBase));
            element_6.DeDataViewFactory = DeDataViewFactory;
            var DeDataView = /** @class */ (function (_super) {
                __extends(DeDataView, _super);
                function DeDataView(factory, element, mode) {
                    var _this = _super.call(this, factory, element) || this;
                    _this.factory = factory;
                    _this.element = element;
                    _this.propertyRoot = null;
                    if (mode == "create") {
                        _this.thead = de.common.addTag(element, "thead");
                        _this.tbody = de.common.addTag(element, "tbody");
                        _this.headerRow = de.common.addTag(_this.thead, "tr");
                        _this.properties.columns = '[{"name":"Header 1"},{"name":"Header 2"}]';
                        _this.setHeader();
                        _this.tbody.dataset.desubtype = "dataview-body";
                    }
                    else if (mode == "load") {
                        _this.thead = element.tHead;
                        _this.tbody = element.tBodies[0];
                        if (de.formatEditor.pageMode == "view") {
                            _this.loadData();
                        }
                    }
                    return _this;
                }
                DeDataView.prototype.getFormData = function (data) {
                    return __awaiter(this, void 0, void 0, function () { return __generator(this, function (_a) {
                        return [2 /*return*/];
                    }); });
                };
                DeDataView.prototype.setFormData = function (data) { };
                DeDataView.prototype.deleteElement = function () {
                    throw new Error("Method not implemented.");
                };
                DeDataView.prototype.showProperty = function (pane) {
                    var _this = this;
                    this.propertyRoot = new element_6.DEEPropertyRoot(pane, this.properties);
                    new element.DEEPropertyItemInput(this.propertyRoot, "data", "Format/Schema Name", "Name of data format.", function (v) {
                        _this.element.name = v;
                        _this.name = v;
                    });
                    var property = new element.DEEPropertyBox(this.propertyRoot, "Propertys");
                    new element.DEEPropertyItemDataTable(property, "columns", [{
                            name: "name",
                            caption: "Name",
                            description: "Column name of item.",
                            notNull: true
                        }, {
                            name: "caption",
                            caption: "Caption",
                            description: "Text displayed in table header list."
                        }, {
                            name: "title",
                            caption: "Title",
                            description: "Text displayed as tooltip."
                        }], "Columns", "Columns of data table", function () {
                        _this.setHeader();
                    });
                    var propertyTool = new element.DEEPropertyGroup(property, "Tool Button");
                    new element.DEEPropertyItemCheckBox(propertyTool, "button_remove", "Remove Button");
                    new element.DEEPropertyItemCheckBox(propertyTool, "button_view", "View Button");
                    new element.DEEPropertyItemCheckBox(propertyTool, "button_edit", "Edit Button");
                    return this.propertyRoot;
                };
                DeDataView.prototype.setReadonly = function () { };
                DeDataView.prototype.onClickFormatMode = function (ev) {
                    element_6.DEEFactroyBase.onActive(this);
                };
                DeDataView.prototype.onClickViewMode = function (ev) { };
                DeDataView.prototype.loadData = function () {
                    return __awaiter(this, void 0, void 0, function () {
                        var dataList, columns, _i, dataList_1, item, _a, tr, tds, c, ex_1;
                        return __generator(this, function (_b) {
                            switch (_b.label) {
                                case 0:
                                    _b.trys.push([0, 2, , 3]);
                                    return [4 /*yield*/, de.common.postJson("".concat(de.common.COMMAND_PATH, "/doc/").concat(this.properties.data, "/getAll"))
                                        // Clear data
                                    ];
                                case 1:
                                    dataList = _b.sent();
                                    // Clear data
                                    this.tbody.innerHTML = "";
                                    columns = JSON.parse(this.properties.columns);
                                    for (_i = 0, dataList_1 = dataList; _i < dataList_1.length; _i++) {
                                        item = dataList_1[_i];
                                        _a = de.common.addTR(this.tbody, columns.length + 2), tr = _a[0], tds = _a[1];
                                        // Tool column
                                        this.setButton(tds[0], item.id);
                                        // ID column
                                        tds[1].innerText = item.id;
                                        // Data columns
                                        for (c = 0; c < columns.length; c++) {
                                            tds[c + 2].innerText = item.data[columns[c].name];
                                        }
                                    }
                                    return [3 /*break*/, 3];
                                case 2:
                                    ex_1 = _b.sent();
                                    console.log("[Data Load Error] data: ".concat(this.properties.data));
                                    return [3 /*break*/, 3];
                                case 3: return [2 /*return*/];
                            }
                        });
                    });
                };
                DeDataView.prototype.setHeader = function () {
                    return __awaiter(this, void 0, void 0, function () {
                        var columns, td_tool, td_id, c, td;
                        return __generator(this, function (_a) {
                            if (this.properties.columns) {
                                columns = JSON.parse(this.properties.columns);
                            }
                            else {
                                columns = [];
                            }
                            this.headerRow.innerHTML = "";
                            td_tool = de.common.addTag(this.headerRow, "td");
                            td_id = de.common.addTag(this.headerRow, "td");
                            td_id.innerText = "ID";
                            for (c = 0; c < columns.length; c++) {
                                td = de.common.addTag(this.headerRow, "td");
                                td.innerText = columns[c].caption || columns[c].name;
                                td.title = columns[c].title || columns[c].caption || columns[c].name;
                            }
                            return [2 /*return*/];
                        });
                    });
                };
                DeDataView.prototype.showData = function (data) {
                    var _this = this;
                    switch (typeof data) {
                        case "string":
                            {
                                return data;
                            }
                            break;
                        case "number":
                            {
                                return data.toString();
                            }
                            break;
                        case "object":
                            {
                                if (Array.isArray(data)) {
                                    return "<div>" + data.map(function (v) { return _this.showData(v); }).join("</div><div>") + "</div>";
                                }
                                else {
                                    var retS = "<table>";
                                    var retE = "</table>";
                                    var retM = "";
                                    for (var k in data) {
                                        retM += "<tr><td>".concat(k, "</td><td>").concat(this.showData(data[k]), "</td></tr>");
                                    }
                                    return retS + retM + retE;
                                }
                            }
                            break;
                        default: {
                            return data.toString();
                        }
                    }
                };
                DeDataView.prototype.setButton = function (td, id) {
                    var _this = this;
                    // Remove Button
                    if (this.properties.button_remove == "1") {
                        de.common.addImageButton(td, "../image/cross.svg", function () { return __awaiter(_this, void 0, void 0, function () {
                            var result;
                            var _a;
                            return __generator(this, function (_b) {
                                switch (_b.label) {
                                    case 0: return [4 /*yield*/, de.common.postJson("".concat(de.common.COMMAND_PATH, "/doc/").concat(this.properties.format, "/remove/").concat(id))];
                                    case 1:
                                        result = _b.sent();
                                        if (result.result) {
                                            (_a = td.parentElement) === null || _a === void 0 ? void 0 : _a.remove();
                                        }
                                        return [2 /*return*/];
                                }
                            });
                        }); });
                    }
                    // View Button
                    if (this.properties.button_view == "1") {
                        de.common.addImageButton(td, "../image/view.svg", function () { return __awaiter(_this, void 0, void 0, function () {
                            return __generator(this, function (_a) {
                                window.open("./viewer.html?format=".concat(this.properties.data, "&id=").concat(id, "&readonly=1"));
                                return [2 /*return*/];
                            });
                        }); });
                    }
                    // Edit Button
                    if (this.properties.button_edit == "1") {
                        de.common.addImageButton(td, "../image/edit.svg", function () { return __awaiter(_this, void 0, void 0, function () {
                            return __generator(this, function (_a) {
                                window.open("./viewer.html?format=".concat(this.properties.data, "&id=").concat(id));
                                return [2 /*return*/];
                            });
                        }); });
                    }
                };
                return DeDataView;
            }(element_6.DEEElementBase));
            element_6.DeDataView = DeDataView;
        })(element = de.element || (de.element = {}));
    })(de = ooo.de || (ooo.de = {}));
})(ooo || (ooo = {}));
var ooo;
(function (ooo) {
    var de;
    (function (de) {
        var element;
        (function (element_7) {
            var DeFileFactory = /** @class */ (function (_super) {
                __extends(DeFileFactory, _super);
                function DeFileFactory() {
                    return _super !== null && _super.apply(this, arguments) || this;
                }
                DeFileFactory.prototype.getType = function () { return "file"; };
                DeFileFactory.prototype.loadElement = function (element) {
                    return new DeFile(this, element, "load");
                };
                DeFileFactory.prototype.makeToolButton = function (toolbutton) {
                    toolbutton.innerHTML = "File Input";
                };
                DeFileFactory.prototype.createElement = function (range) {
                    var valueElementPair = this.createSimpleElement(range, function (value, doc) {
                        var element = doc.createElement("span");
                        element.classList.add("file");
                        element.contentEditable = "false";
                        return element;
                    });
                    var deInput = new DeFile(this, valueElementPair.element, "create");
                    deInput.properties.default_value = valueElementPair.value;
                    return deInput;
                };
                return DeFileFactory;
            }(element_7.DEEFactroyBase));
            element_7.DeFileFactory = DeFileFactory;
            var DeFile = /** @class */ (function (_super) {
                __extends(DeFile, _super);
                function DeFile(factory, element, mode) {
                    var _this = _super.call(this, factory, element) || this;
                    _this.propertyRoot = null;
                    _this.fileUpdatedFlug = false;
                    _this.previousData = [];
                    if (mode == "create") {
                        _this.input = de.common.addTag(_this.element, "input");
                        _this.input.type = "file";
                        _this.input.dataset.desubtype = "file-input";
                        _this.input.addEventListener("change", function () {
                            _this.fileUpdatedFlug = true;
                            _this.downloadButton.disabled = true;
                        });
                        _this.downloadButton = de.common.addTag(_this.element, "button");
                        _this.downloadButton.dataset.desubtype = "file-download";
                        var downloadImg = de.common.addTag(_this.downloadButton, "img");
                        downloadImg.src = "../image/load.svg";
                        downloadImg.style.width = "15px";
                        downloadImg.style.height = "15px";
                        _this.deleteButton = de.common.addTag(_this.element, "button");
                        _this.deleteButton.dataset.desubtype = "file-delete";
                        var deleteImg = de.common.addTag(_this.deleteButton, "img");
                        deleteImg.src = "../image/cross.svg";
                        deleteImg.style.width = "15px";
                        deleteImg.style.height = "15px";
                    }
                    else if (mode == "load") {
                        _this.input = _this.element.children[0];
                        _this.downloadButton = _this.element.children[1];
                        _this.deleteButton = _this.element.children[2];
                        _this.downloadButton.disabled = false;
                    }
                    if (de.formatEditor.pageMode == "view") {
                        _this.downloadButton.addEventListener("click", function () {
                            _this.download();
                        });
                        _this.deleteButton.addEventListener("click", function () {
                            _this.input.value = "";
                        });
                    }
                    return _this;
                }
                DeFile.prototype.getFormData = function (data) {
                    return __awaiter(this, void 0, void 0, function () {
                        var fileList, i, file, fileData, fileString;
                        return __generator(this, function (_a) {
                            switch (_a.label) {
                                case 0:
                                    if (!this.properties.name) return [3 /*break*/, 5];
                                    fileList = [];
                                    if (!this.input.files) return [3 /*break*/, 4];
                                    i = 0;
                                    _a.label = 1;
                                case 1:
                                    if (!(i < this.input.files.length)) return [3 /*break*/, 4];
                                    file = this.input.files[i];
                                    return [4 /*yield*/, file.arrayBuffer()];
                                case 2:
                                    fileData = _a.sent();
                                    fileString = de.common.ArrayBufferToBase64(fileData);
                                    fileList.push({
                                        "name": file.name,
                                        "data": fileString
                                    });
                                    _a.label = 3;
                                case 3:
                                    i++;
                                    return [3 /*break*/, 1];
                                case 4:
                                    data[this.properties.name] = fileList;
                                    _a.label = 5;
                                case 5: return [2 /*return*/];
                            }
                        });
                    });
                };
                DeFile.prototype.setFormData = function (data) {
                    var _a;
                    if (this.properties.name) {
                        this.fileUpdatedFlug = false;
                        this.downloadButton.disabled = false;
                        this.previousData = (_a = data[this.properties.name]) !== null && _a !== void 0 ? _a : [];
                    }
                };
                DeFile.prototype.deleteElement = function () {
                    throw new Error("Method not implemented.");
                };
                DeFile.prototype.showProperty = function (pane) {
                    var _this = this;
                    this.propertyRoot = new element_7.DEEPropertyRoot(pane, this.properties);
                    new element.DEEPropertyItemInput(this.propertyRoot, "name", "Name", "Name of this element.", function (v) {
                        _this.element.name = v;
                        _this.name = v;
                    });
                    var property = new element.DEEPropertyBox(this.propertyRoot, "Property");
                    new element.DEEPropertyItemInput(property, "placeholder", "Placeholder", "Placeholder of the text box", function (v) {
                        _this.element.placeholder = v;
                    });
                    return this.propertyRoot;
                };
                DeFile.prototype.setReadonly = function () {
                    this.input.setAttribute("readonly", "readonly");
                    this.deleteButton.setAttribute("readonly", "readonly");
                };
                DeFile.prototype.onClickFormatMode = function (ev) {
                    element_7.DEEFactroyBase.onActive(this);
                };
                DeFile.prototype.onClickViewMode = function (ev) { };
                DeFile.prototype.getSchema = function (schema) {
                    schema[this.properties.name] = {
                        type: "text"
                    };
                };
                DeFile.prototype.download = function () {
                    if (this.previousData.length > 0) {
                        for (var _i = 0, _a = this.previousData; _i < _a.length; _i++) {
                            var fileInfo = _a[_i];
                            var file = new File([de.common.Base64ToArrayBuffer(fileInfo.data)], fileInfo.name);
                            var url = window.URL.createObjectURL(file);
                            var link = document.createElement("a");
                            link.href = url;
                            link.download = fileInfo.name;
                            link.click();
                        }
                    }
                };
                DeFile.prototype.onAfterCreate = function () {
                    this.properties.name = this.id;
                };
                return DeFile;
            }(element_7.DEEElementBase));
            element_7.DeFile = DeFile;
        })(element = de.element || (de.element = {}));
    })(de = ooo.de || (ooo.de = {}));
})(ooo || (ooo = {}));
var ooo;
(function (ooo) {
    var de;
    (function (de) {
        var element;
        (function (element_8) {
            var DeImageFactory = /** @class */ (function (_super) {
                __extends(DeImageFactory, _super);
                function DeImageFactory() {
                    return _super !== null && _super.apply(this, arguments) || this;
                }
                DeImageFactory.prototype.getType = function () { return "image"; };
                DeImageFactory.prototype.loadElement = function (element) {
                    return new DeImage(this, element);
                };
                DeImageFactory.prototype.makeToolButton = function (toolbutton) {
                    toolbutton.innerHTML = "Image";
                };
                DeImageFactory.prototype.createElement = function (range) {
                    var valueElementPair = this.createSimpleElement(range, function (value, doc) {
                        var element = doc.createElement("img");
                        element.style.width = "20px";
                        return element;
                    });
                    var dee = new DeImage(this, valueElementPair.element);
                    dee.properties.width = "20";
                    dee.objectToDataset();
                    return dee;
                };
                return DeImageFactory;
            }(element_8.DEEFactroyBase));
            element_8.DeImageFactory = DeImageFactory;
            var DeImage = /** @class */ (function (_super) {
                __extends(DeImage, _super);
                function DeImage() {
                    var _this = _super !== null && _super.apply(this, arguments) || this;
                    _this.propertyRoot = null;
                    return _this;
                }
                DeImage.prototype.getFormData = function (data) {
                    return __awaiter(this, void 0, void 0, function () { return __generator(this, function (_a) {
                        return [2 /*return*/];
                    }); });
                };
                DeImage.prototype.setFormData = function (data) { };
                DeImage.prototype.deleteElement = function () {
                    throw new Error("Method not implemented.");
                };
                DeImage.prototype.showProperty = function (pane) {
                    var _this = this;
                    this.propertyRoot = new element_8.DEEPropertyRoot(pane, this.properties);
                    var property = new element.DEEPropertyBox(this.propertyRoot, "Property");
                    var property_image = new element.DEEPropertyItemFile(property, "image", "Image File", "Upload image file.", function (v) {
                        var reader = new FileReader();
                        if (property_image.input.files && property_image.input.files[0]) {
                            reader.addEventListener("load", function () {
                                _this.element.src = reader.result;
                            });
                            reader.readAsDataURL(property_image.input.files[0]);
                        }
                    });
                    new element.DEEPropertyItemInput(property, "width", "Image width", "Set image width.", function (v) {
                        _this.element.style.width = (v == "0" || v == "") ? "" : v + "px";
                    }, "number");
                    property.getBody().append("px");
                    new element.DEEPropertyItemInput(property, "height", "Image height", "Set image height.", function (v) {
                        _this.element.style.height = (v == "0" || v == "") ? "" : v + "px";
                    }, "number");
                    property.getBody().append("px");
                    return this.propertyRoot;
                };
                DeImage.prototype.setReadonly = function () {
                    this.element.setAttribute("readonly", "readonly");
                };
                DeImage.prototype.onClickFormatMode = function (ev) {
                    element_8.DEEFactroyBase.onActive(this);
                };
                DeImage.prototype.onClickViewMode = function (ev) { };
                DeImage.prototype.getSchema = function (schema) {
                    schema[this.properties.name] = {
                        type: "text"
                    };
                };
                DeImage.prototype.onAfterCreate = function () {
                    this.properties.name = this.id;
                };
                return DeImage;
            }(element_8.DEEElementBase));
            element_8.DeImage = DeImage;
        })(element = de.element || (de.element = {}));
    })(de = ooo.de || (ooo.de = {}));
})(ooo || (ooo = {}));
var ooo;
(function (ooo) {
    var de;
    (function (de) {
        var element;
        (function (element_9) {
            var DeInputFactory = /** @class */ (function (_super) {
                __extends(DeInputFactory, _super);
                function DeInputFactory() {
                    return _super !== null && _super.apply(this, arguments) || this;
                }
                DeInputFactory.prototype.getType = function () { return "input"; };
                DeInputFactory.prototype.loadElement = function (element) {
                    return new DeInput(this, element);
                };
                DeInputFactory.prototype.makeToolButton = function (toolbutton) {
                    toolbutton.innerHTML = "Text Box";
                };
                DeInputFactory.prototype.createElement = function (range) {
                    var valueElementPair = this.createSimpleElement(range, function (value, doc) {
                        var element = doc.createElement("input");
                        element.value = value;
                        element.contentEditable = "false";
                        return element;
                    });
                    var deInput = new DeInput(this, valueElementPair.element);
                    deInput.properties.default_value = valueElementPair.value;
                    return deInput;
                };
                return DeInputFactory;
            }(element_9.DEEFactroyBase));
            element_9.DeInputFactory = DeInputFactory;
            var DeInput = /** @class */ (function (_super) {
                __extends(DeInput, _super);
                function DeInput() {
                    var _this = _super !== null && _super.apply(this, arguments) || this;
                    _this.propertyRoot = null;
                    return _this;
                }
                DeInput.prototype.getFormData = function (data) {
                    return __awaiter(this, void 0, void 0, function () {
                        return __generator(this, function (_a) {
                            if (this.properties.name) {
                                data[this.properties.name] = this.element.value;
                            }
                            return [2 /*return*/];
                        });
                    });
                };
                DeInput.prototype.setFormData = function (data) {
                    var _a, _b;
                    if (this.properties.name) {
                        this.element.value = (_b = (_a = data[this.properties.name]) !== null && _a !== void 0 ? _a : this.properties.default_value) !== null && _b !== void 0 ? _b : "";
                    }
                };
                DeInput.prototype.deleteElement = function () {
                    throw new Error("Method not implemented.");
                };
                DeInput.prototype.showProperty = function (pane) {
                    var _this = this;
                    this.propertyRoot = new element_9.DEEPropertyRoot(pane, this.properties);
                    new element.DEEPropertyItemInput(this.propertyRoot, "name", "Name", "Name of this element.", function (v) {
                        _this.element.name = v;
                        _this.name = v;
                    });
                    var property = new element.DEEPropertyBox(this.propertyRoot, "Property");
                    new element.DEEPropertyItemInput(property, "default_value", "Default Value", "Default value of the text box", function (v) {
                        _this.element.value = v;
                    });
                    new element.DEEPropertyItemInput(property, "placeholder", "Placeholder", "Placeholder of the text box", function (v) {
                        _this.element.placeholder = v;
                    });
                    return this.propertyRoot;
                };
                DeInput.prototype.setReadonly = function () {
                    this.element.setAttribute("readonly", "readonly");
                };
                DeInput.prototype.onClickFormatMode = function (ev) {
                    element_9.DEEFactroyBase.onActive(this);
                };
                DeInput.prototype.onClickViewMode = function (ev) { };
                DeInput.prototype.getSchema = function (schema) {
                    schema[this.properties.name] = {
                        type: "text"
                    };
                };
                DeInput.prototype.onAfterCreate = function () {
                    this.properties.name = this.id;
                };
                return DeInput;
            }(element_9.DEEElementBase));
            element_9.DeInput = DeInput;
        })(element = de.element || (de.element = {}));
    })(de = ooo.de || (ooo.de = {}));
})(ooo || (ooo = {}));
var ooo;
(function (ooo) {
    var de;
    (function (de) {
        var element;
        (function (element_10) {
            var DeInputExFactory = /** @class */ (function (_super) {
                __extends(DeInputExFactory, _super);
                function DeInputExFactory(type, innerHTML) {
                    var _this = _super.call(this) || this;
                    _this.type = type;
                    _this.innerHTML = innerHTML;
                    return _this;
                }
                DeInputExFactory.prototype.getType = function () { return "input_" + this.type; };
                DeInputExFactory.prototype.loadElement = function (element) {
                    return new element_10.DeInput(this, element);
                };
                DeInputExFactory.prototype.makeToolButton = function (toolbutton) {
                    toolbutton.innerHTML = this.innerHTML;
                };
                DeInputExFactory.prototype.createElement = function (range) {
                    var _this = this;
                    var valueElementPair = this.createSimpleElement(range, function (value, doc) {
                        var element = doc.createElement("input");
                        element.value = value;
                        element.type = _this.type;
                        element.contentEditable = "false";
                        return element;
                    });
                    var deInput = new element_10.DeInput(this, valueElementPair.element);
                    deInput.properties.default_value = valueElementPair.value;
                    return deInput;
                };
                return DeInputExFactory;
            }(element_10.DEEFactroyBase));
            element_10.DeInputExFactory = DeInputExFactory;
        })(element = de.element || (de.element = {}));
    })(de = ooo.de || (ooo.de = {}));
})(ooo || (ooo = {}));
var ooo;
(function (ooo) {
    var de;
    (function (de) {
        var element;
        (function (element_11) {
            var DeLinkFactory = /** @class */ (function (_super) {
                __extends(DeLinkFactory, _super);
                function DeLinkFactory() {
                    return _super !== null && _super.apply(this, arguments) || this;
                }
                DeLinkFactory.prototype.getType = function () { return "link"; };
                DeLinkFactory.prototype.loadElement = function (element) {
                    return new element_11.DeInput(this, element);
                };
                DeLinkFactory.prototype.makeToolButton = function (toolbutton) {
                    toolbutton.innerHTML = "Link";
                };
                DeLinkFactory.prototype.createElement = function (range) {
                    var valueElementPair = this.createSimpleElement(range, function (value, doc) {
                        var element = doc.createElement("a");
                        element.innerText = value;
                        element.contentEditable = "false";
                        return element;
                    });
                    var deInput = new DeLink(this, valueElementPair.element);
                    deInput.properties.text = valueElementPair.value;
                    return deInput;
                };
                return DeLinkFactory;
            }(element_11.DEEFactroyBase));
            element_11.DeLinkFactory = DeLinkFactory;
            var DeLink = /** @class */ (function (_super) {
                __extends(DeLink, _super);
                function DeLink() {
                    var _this = _super !== null && _super.apply(this, arguments) || this;
                    _this.propertyRoot = null;
                    return _this;
                }
                DeLink.prototype.getFormData = function (data) {
                    return __awaiter(this, void 0, void 0, function () {
                        return __generator(this, function (_a) {
                            if (this.properties.name) {
                                data[this.properties.name] = this.element.value;
                            }
                            return [2 /*return*/];
                        });
                    });
                };
                DeLink.prototype.setFormData = function (data) {
                    var _a, _b;
                    if (this.properties.name) {
                        this.element.value = (_b = (_a = data[this.properties.name]) !== null && _a !== void 0 ? _a : this.properties.default_value) !== null && _b !== void 0 ? _b : "";
                    }
                };
                DeLink.prototype.deleteElement = function () {
                    throw new Error("Method not implemented.");
                };
                DeLink.prototype.showProperty = function (pane) {
                    var _this = this;
                    this.propertyRoot = new element_11.DEEPropertyRoot(pane, this.properties);
                    var property = new element.DEEPropertyBox(this.propertyRoot, "Property");
                    new element.DEEPropertyItemInput(property, "text", "Caption text", "Text of the item.", function (v) {
                        _this.element.innerText = v;
                    });
                    new element.DEEPropertyItemInput(property, "link", "Link", "Link of the item.", function (v) {
                        _this.element.href = v;
                    });
                    return this.propertyRoot;
                };
                DeLink.prototype.setReadonly = function () {
                    this.element.setAttribute("readonly", "readonly");
                };
                DeLink.prototype.onClickFormatMode = function (ev) {
                    element_11.DEEFactroyBase.onActive(this);
                };
                DeLink.prototype.onClickViewMode = function (ev) { };
                DeLink.prototype.getSchema = function (schema) {
                    schema[this.properties.name] = {
                        type: "text"
                    };
                };
                DeLink.prototype.onAfterCreate = function () {
                    this.properties.name = this.id;
                };
                return DeLink;
            }(element_11.DEEElementBase));
            element_11.DeLink = DeLink;
        })(element = de.element || (de.element = {}));
    })(de = ooo.de || (ooo.de = {}));
})(ooo || (ooo = {}));
var ooo;
(function (ooo) {
    var de;
    (function (de) {
        var element;
        (function (element_12) {
            var DeRadioFactory = /** @class */ (function (_super) {
                __extends(DeRadioFactory, _super);
                function DeRadioFactory() {
                    return _super !== null && _super.apply(this, arguments) || this;
                }
                DeRadioFactory.prototype.getType = function () { return "radio"; };
                DeRadioFactory.prototype.loadElement = function (element) {
                    return new DeRadio(this, element, "", "load");
                };
                DeRadioFactory.prototype.makeToolButton = function (toolbutton) {
                    toolbutton.innerHTML = "Radio Button";
                };
                DeRadioFactory.prototype.createElement = function (range) {
                    var valueElementPair = this.createSimpleElement(range, function (value, doc) {
                        var element = doc.createElement("label");
                        element.contentEditable = "false";
                        return element;
                    });
                    var deRadio = new DeRadio(this, valueElementPair.element, valueElementPair.value, "create");
                    return deRadio;
                };
                return DeRadioFactory;
            }(element_12.DEEFactroyBase));
            element_12.DeRadioFactory = DeRadioFactory;
            var DeRadio = /** @class */ (function (_super) {
                __extends(DeRadio, _super);
                function DeRadio(factory, element, value, mode) {
                    var _this = _super.call(this, factory, element) || this;
                    _this.factory = factory;
                    _this.element = element;
                    _this.propertyRoot = null;
                    if (mode == "create") {
                        _this.radioElement = de.common.addTag(element, "input");
                        _this.radioElement.type = "radio";
                        _this.radioElement.dataset.desubtype = "radio";
                        _this.textElement = de.common.addTag(element, "span");
                        _this.textElement.innerText = value;
                        _this.textElement.dataset.desubtype = "text";
                        _this.properties.value = value;
                        _this.properties.caption = value;
                    }
                    else if (mode == "load") {
                        for (var i = 0; i < element.children.length; i++) {
                            var child = element.children.item(i);
                            if (child instanceof HTMLInputElement && child.dataset.desubtype == "radio") {
                                _this.radioElement = child;
                            }
                            else if (child instanceof HTMLSpanElement && child.dataset.desubtype == "text") {
                                _this.textElement = child;
                            }
                        }
                    }
                    return _this;
                }
                DeRadio.prototype.getFormData = function (data) {
                    return __awaiter(this, void 0, void 0, function () {
                        return __generator(this, function (_a) {
                            if (this.radioElement.checked) {
                                data[this.properties.name] = this.properties.value;
                            }
                            return [2 /*return*/];
                        });
                    });
                };
                DeRadio.prototype.setFormData = function (data) {
                    if (data[this.properties.name] == this.properties.value) {
                        this.radioElement.checked = true;
                    }
                };
                DeRadio.prototype.deleteElement = function () {
                    throw new Error("Method not implemented.");
                };
                DeRadio.prototype.showProperty = function (pane) {
                    var _this = this;
                    this.propertyRoot = new element_12.DEEPropertyRoot(pane, this.properties);
                    new element.DEEPropertyItemInput(this.propertyRoot, "name", "Name", "Name of this element. Set the same name for the same radio group.", function (v) {
                        _this.radioElement.name = v;
                        _this.name = v;
                    });
                    var property = new element.DEEPropertyBox(this.propertyRoot, "Property");
                    new element.DEEPropertyItemInput(property, "value", "Value", "Value of this element.", function (v) {
                        _this.textElement.innerText = _this.properties.caption || v;
                        _this.radioElement.value = v;
                    });
                    new element.DEEPropertyItemInput(property, "caption", "Caption", "Caption of this element.", function (v) {
                        _this.textElement.innerText = _this.properties.caption || v;
                    });
                    new element.DEEPropertyItemCheckBox(property, "default", "Default", "Check if this item is default.", function (v) {
                        _this.radioElement.checked = v;
                        for (var _i = 0, _a = element_12.DEEElementBase.elementList; _i < _a.length; _i++) {
                            var dee = _a[_i];
                            // unset radio buttons with the same name.
                            if (dee instanceof DeRadio && dee.properties.name == _this.properties.name && dee != _this) {
                                dee.unSetDefault();
                            }
                        }
                    });
                    return this.propertyRoot;
                };
                DeRadio.prototype.setReadonly = function () {
                    this.element.setAttribute("readonly", "readonly");
                };
                DeRadio.prototype.onClickFormatMode = function (ev) {
                    element_12.DEEFactroyBase.onActive(this);
                };
                DeRadio.prototype.onClickViewMode = function (ev) { };
                DeRadio.prototype.unSetDefault = function () {
                    this.properties.default = "0";
                    this.radioElement.checked = false;
                };
                DeRadio.prototype.getSchema = function (schema) {
                    if (schema[this.properties.name]) {
                        schema[this.properties.name].options.push(this.properties.value);
                        schema[this.properties.name].optionsCaption.push(this.properties.caption);
                    }
                    else {
                        schema[this.properties.name] = {
                            type: "list",
                            options: [this.properties.value],
                            optionsCaption: [this.properties.caption]
                        };
                    }
                };
                DeRadio.prototype.onAfterCreate = function () {
                    this.properties.name = "radio-name";
                };
                return DeRadio;
            }(element_12.DEEElementBase));
            element_12.DeRadio = DeRadio;
        })(element = de.element || (de.element = {}));
    })(de = ooo.de || (ooo.de = {}));
})(ooo || (ooo = {}));
var ooo;
(function (ooo) {
    var de;
    (function (de) {
        var element;
        (function (element_13) {
            var DeSelectFactory = /** @class */ (function (_super) {
                __extends(DeSelectFactory, _super);
                function DeSelectFactory() {
                    return _super !== null && _super.apply(this, arguments) || this;
                }
                DeSelectFactory.prototype.getType = function () { return "select"; };
                DeSelectFactory.prototype.loadElement = function (element) {
                    var deSelect = new DeSelect(this, element);
                    if (deSelect.properties.default_value) {
                        element.value = deSelect.properties.default_value;
                    }
                    return deSelect;
                };
                DeSelectFactory.prototype.makeToolButton = function (toolbutton) {
                    toolbutton.innerHTML = "Select";
                };
                DeSelectFactory.prototype.createElement = function (range) {
                    var valueElementPair = this.createSimpleElement(range, function (value, doc) {
                        var element = doc.createElement("select");
                        element.contentEditable = "false";
                        return element;
                    });
                    var deSelect = new DeSelect(this, valueElementPair.element);
                    return deSelect;
                };
                return DeSelectFactory;
            }(element_13.DEEFactroyBase));
            element_13.DeSelectFactory = DeSelectFactory;
            var DeSelect = /** @class */ (function (_super) {
                __extends(DeSelect, _super);
                function DeSelect() {
                    var _this = _super !== null && _super.apply(this, arguments) || this;
                    _this.propertyRoot = null;
                    return _this;
                }
                DeSelect.prototype.getFormData = function (data) {
                    return __awaiter(this, void 0, void 0, function () {
                        return __generator(this, function (_a) {
                            if (this.properties.name) {
                                data[this.properties.name] = this.element.value;
                            }
                            return [2 /*return*/];
                        });
                    });
                };
                DeSelect.prototype.setFormData = function (data) {
                    var _a, _b;
                    if (this.properties.name) {
                        this.element.value = (_b = (_a = data[this.properties.name]) !== null && _a !== void 0 ? _a : this.properties.default_value) !== null && _b !== void 0 ? _b : "";
                    }
                };
                DeSelect.prototype.deleteElement = function () {
                    throw new Error("Method not implemented.");
                };
                DeSelect.prototype.showProperty = function (pane) {
                    var _this = this;
                    this.propertyRoot = new element_13.DEEPropertyRoot(pane, this.properties);
                    new element.DEEPropertyItemInput(this.propertyRoot, "name", "Name", "Name of this element.", function (v) {
                        _this.element.name = v;
                        _this.name = v;
                    });
                    var property = new element.DEEPropertyBox(this.propertyRoot, "Property");
                    new element.DEEPropertyItemInput(property, "default_value", "Default Value", "Default value of the text box", function (v) {
                        _this.element.value = v;
                    });
                    var propertyOptions = new element.DEEPropertyItemDataTable(property, "options", [{
                            name: "value",
                            caption: "Value",
                            description: "Data value of item.",
                            notNull: true
                        }, {
                            name: "caption",
                            caption: "Caption",
                            description: "Text displayed in option list."
                        }], "Options", "Options of select", function () {
                        var select = _this.element;
                        select.innerHTML = "";
                        for (var _i = 0, _a = JSON.parse(propertyOptions.data.options); _i < _a.length; _i++) {
                            var d = _a[_i];
                            var option = de.common.addTag(select, "option");
                            option.innerText = d.caption || d.value;
                            option.value = d.value;
                        }
                    });
                    return this.propertyRoot;
                };
                DeSelect.prototype.setReadonly = function () {
                    this.element.setAttribute("readonly", "readonly");
                };
                DeSelect.prototype.onClickFormatMode = function (ev) {
                    element_13.DEEFactroyBase.onActive(this);
                };
                DeSelect.prototype.onClickViewMode = function (ev) { };
                DeSelect.prototype.getSchema = function (schema) {
                    schema[this.properties.name] = {
                        type: "list",
                        options: JSON.parse(this.properties.options).map(function (v) { return v.value; }),
                        optionsCaption: JSON.parse(this.properties.options).map(function (v) { return v.caption; })
                    };
                };
                DeSelect.prototype.onAfterCreate = function () {
                    this.properties.name = this.id;
                };
                return DeSelect;
            }(element_13.DEEElementBase));
            element_13.DeSelect = DeSelect;
        })(element = de.element || (de.element = {}));
    })(de = ooo.de || (ooo.de = {}));
})(ooo || (ooo = {}));
var ooo;
(function (ooo) {
    var de;
    (function (de) {
        var element;
        (function (element_14) {
            var DEFAULT_COLUMNS = 2;
            var DEFAULT_ROWS = 2;
            var tableClassList = ["grid", "pane"];
            function getTop(info) {
                return info.row;
            }
            function getBottom(info) {
                return info.row + info.cell.rowSpan;
            }
            function getLeft(info) {
                return info.column;
            }
            function getRight(info) {
                return info.column + info.cell.colSpan;
            }
            function getNextCell(tableInfo, row, col) {
                var ret = null;
                for (var c = col; c < tableInfo[0].length; c++) {
                    if (tableInfo[row][c].row == row) {
                        return tableInfo[row][c].cell;
                    }
                }
                return ret;
            }
            var DeTableFactory = /** @class */ (function (_super) {
                __extends(DeTableFactory, _super);
                function DeTableFactory() {
                    return _super !== null && _super.apply(this, arguments) || this;
                }
                DeTableFactory.prototype.getType = function () { return "table"; };
                DeTableFactory.prototype.loadElement = function (element) {
                    return new DeTable(this, element);
                };
                DeTableFactory.prototype.makeToolButton = function (toolbutton) {
                    toolbutton.innerHTML = "TABLE";
                };
                DeTableFactory.prototype.createElement = function (range) {
                    var valueElementPair = this.createSimpleElement(range, function (value, doc) {
                        var element = doc.createElement("table");
                        element.classList.add(tableClassList[0]);
                        return element;
                    });
                    var deTable = new DeTable(this, valueElementPair.element);
                    for (var r = 0; r < DEFAULT_ROWS; r++) {
                        var _a = de.common.addTR(valueElementPair.element, DEFAULT_COLUMNS), tr = _a[0], tds = _a[1];
                        for (var _i = 0, tds_1 = tds; _i < tds_1.length; _i++) {
                            var td = tds_1[_i];
                            de.common.addTag(td, "div");
                        }
                    }
                    deTable.properties.border = "1";
                    deTable.properties.columns = DEFAULT_COLUMNS.toString();
                    deTable.properties.rows = DEFAULT_ROWS.toString();
                    return deTable;
                };
                return DeTableFactory;
            }(element_14.DEEFactroyBase));
            element_14.DeTableFactory = DeTableFactory;
            var DeTable = /** @class */ (function (_super) {
                __extends(DeTable, _super);
                function DeTable() {
                    var _this = _super !== null && _super.apply(this, arguments) || this;
                    _this.propertyRoot = null;
                    _this.rows = DEFAULT_ROWS;
                    _this.columns = DEFAULT_COLUMNS;
                    return _this;
                    //#endregion
                }
                DeTable.prototype.getFormData = function (data) {
                    return __awaiter(this, void 0, void 0, function () { return __generator(this, function (_a) {
                        return [2 /*return*/];
                    }); });
                };
                DeTable.prototype.setFormData = function (data) { };
                DeTable.prototype.deleteElement = function () {
                    throw new Error("Method not implemented.");
                };
                DeTable.prototype.showProperty = function (pane) {
                    var _this = this;
                    this.propertyRoot = new element_14.DEEPropertyRoot(pane, this.properties);
                    var property = new element.DEEPropertyBox(this.propertyRoot, "Property");
                    new element.DEEPropertyItemInput(property, "columns", "Columns", "Columns number", function (v) {
                        _this.onChangeTableSize();
                    }, "number");
                    new element.DEEPropertyItemInput(property, "rows", "Rows", "Rows number", function (v) {
                        _this.onChangeTableSize();
                    }, "number");
                    var propertyStyle = new element_14.DEEPropertyGroup(property, "Table style");
                    new element.DEEPropertyItemCheckBox(propertyStyle, "border", "Border", "", function (v) {
                        if (v) {
                            _this.element.classList.add("grid");
                        }
                        else {
                            _this.element.classList.remove("grid");
                        }
                    });
                    var tool = new element.DEEPropertyBox(this.propertyRoot, "Tool");
                    var toolExpandGroup = new element.DEEPropertyGroup(tool, "Expand");
                    new element.DEEPropertyItemButton(toolExpandGroup, "", "rightArrow.svg", "", function () {
                        _this.expandColRight();
                    });
                    new element.DEEPropertyItemButton(toolExpandGroup, "", "downArrow.svg", "", function () {
                        _this.expandRowBottom();
                    });
                    var toolShrinkGroup = new element.DEEPropertyGroup(tool, "Shrink");
                    new element.DEEPropertyItemButton(toolShrinkGroup, "", "leftArrow.svg", "", function () {
                        _this.shrinkRight();
                    });
                    new element.DEEPropertyItemButton(toolShrinkGroup, "", "upArrow.svg", "", function () {
                        _this.shrinkBottom();
                    });
                    this.rows = this.getCurrentRows();
                    this.columns = this.getCurrentColumns();
                    return this.propertyRoot;
                };
                DeTable.prototype.setReadonly = function () {
                    this.element.setAttribute("readonly", "readonly");
                };
                DeTable.prototype.onClickFormatMode = function (ev) {
                    element_14.DEEFactroyBase.onActive(this);
                    if (ev.target) {
                        this.targetTD = this.getTargetTD(ev.target);
                    }
                };
                DeTable.prototype.onClickViewMode = function (ev) { };
                //#region Table Size Changing
                DeTable.prototype.onChangeTableSize = function () {
                    var newRows = Number(this.properties.rows);
                    var newColumns = Number(this.properties.columns);
                    var table = this.element;
                    var currentRows = this.getCurrentRows();
                    var currentColumns = this.getCurrentColumns();
                    var info = this.getTableMergeInfo();
                    // Shrink Rows
                    if (newRows < currentRows) {
                        for (var c = 0; c < currentColumns; c++) {
                            if (info[newRows][c].column == c) {
                                if (info[newRows][c].row < newRows) {
                                    info[newRows][c].cell.rowSpan = newRows - info[newRows][c].row;
                                }
                            }
                        }
                        for (var r = newRows; r < currentRows; r++) {
                            table.rows[r].remove();
                        }
                    }
                    // Expand Rows
                    else if (newRows > currentRows) {
                        for (var r = currentRows; r < newRows; r++) {
                            var _a = de.common.addTR(table, currentColumns), tds = _a[1];
                            for (var _i = 0, tds_2 = tds; _i < tds_2.length; _i++) {
                                var td = tds_2[_i];
                                de.common.addTag(td, "div");
                            }
                        }
                    }
                    // Reset Information
                    info = this.getTableMergeInfo();
                    // Shrink Columns
                    if (newColumns < currentColumns) {
                        for (var r = 0; r < newRows; r++) {
                            if (info[r][newColumns].row == r) {
                                if (info[r][newColumns].column < newColumns) {
                                    info[r][newColumns].cell.colSpan = newColumns - info[r][newColumns].column;
                                }
                                else {
                                    info[r][newColumns].cell.remove();
                                }
                            }
                            for (var c = newColumns + 1; c < currentColumns; c++) {
                                if (info[r][c].row == r &&
                                    info[r][c].column == c) {
                                    info[r][c].cell.remove();
                                }
                            }
                        }
                    }
                    // Expand Columns
                    else if (newColumns > currentColumns) {
                        for (var r = 0; r < newRows; r++) {
                            var row = table.rows[r];
                            for (var c = currentColumns; c < newColumns; c++) {
                                var td = de.common.addTag(row, "td");
                                de.common.addTag(td, "div");
                            }
                        }
                    }
                    this.columns = newColumns;
                    this.rows = newRows;
                };
                DeTable.prototype.getCurrentColumns = function () {
                    var columns = 0;
                    if (this.element.rows.length > 0) {
                        var row = this.element.rows[0];
                        for (var c = 0; c < row.cells.length; c++) {
                            columns += row.cells[c].colSpan;
                        }
                    }
                    return columns;
                };
                DeTable.prototype.getCurrentRows = function () {
                    return this.element.rows.length;
                };
                DeTable.prototype.getTargetTD = function (node) {
                    var cur = node instanceof HTMLElement ? node : node.parentElement;
                    var td;
                    while (cur) {
                        if (cur instanceof HTMLTableCellElement) {
                            td = cur;
                        }
                        else if (cur == this.element) {
                            return td;
                        }
                        cur = cur.parentElement;
                    }
                    this.targetTD = undefined;
                };
                DeTable.prototype.getTableMergeInfo = function () {
                    var data = [];
                    var rows = this.getCurrentRows();
                    var columns = this.getCurrentColumns();
                    // initialize table
                    for (var row = 0; row < rows; row++) {
                        var rowData = [];
                        data.push(rowData);
                        for (var column = 0; column < columns; column++) {
                            rowData.push(undefined);
                        }
                    }
                    // get information
                    for (var row = 0; row < rows; row++) {
                        var columnIndex = 0;
                        for (var column = 0; column < columns; column++) {
                            if (data[row][column] == undefined) {
                                var td = this.element.rows[row].cells[columnIndex];
                                for (var sr = 0; sr < td.rowSpan; sr++) {
                                    for (var sc = 0; sc < td.colSpan; sc++) {
                                        data[row + sr][column + sc] = {
                                            row: row,
                                            column: column,
                                            cell: td
                                        };
                                    }
                                }
                                columnIndex++;
                            }
                        }
                    }
                    return data;
                };
                DeTable.prototype.expandColRight = function () {
                    var _this = this;
                    if (this.targetTD) {
                        var tableInfo = this.getTableMergeInfo();
                        var targetCellInfo = tableInfo.map(function (v) { return v.find(function (v) { return v.cell == _this.targetTD; }); })
                            .find(function (v) { return v != undefined; });
                        // check if target cell is in the table.
                        if (targetCellInfo == undefined) {
                            return;
                        }
                        // check if the td can be expanded in right direction.
                        if (getRight(targetCellInfo) >= this.columns) {
                            return;
                        }
                        // check merged cell collision.
                        var rightTopCellInfo = tableInfo[getTop(targetCellInfo)][getRight(targetCellInfo)];
                        var rightBottomCellInfo = tableInfo[getBottom(targetCellInfo) - 1][getRight(targetCellInfo)];
                        if (getTop(rightTopCellInfo) < getTop(targetCellInfo)) {
                            return;
                        }
                        if (getBottom(rightBottomCellInfo) > getBottom(targetCellInfo)) {
                            return;
                        }
                        // shrink next cells.
                        var shrinkCol = getRight(targetCellInfo);
                        for (var r = getTop(targetCellInfo); r < getBottom(targetCellInfo);) {
                            var nextCellInfo = tableInfo[r][shrinkCol];
                            if (nextCellInfo.cell.colSpan > 1) {
                                nextCellInfo.cell.colSpan--;
                            }
                            else {
                                nextCellInfo.cell.remove();
                            }
                            r += nextCellInfo.cell.rowSpan;
                        }
                        // expand cell
                        this.targetTD.colSpan++;
                    }
                };
                DeTable.prototype.expandRowBottom = function () {
                    var _this = this;
                    if (this.targetTD) {
                        var tableInfo = this.getTableMergeInfo();
                        var targetCellInfo = tableInfo.map(function (v) { return v.find(function (v) { return v.cell == _this.targetTD; }); })
                            .find(function (v) { return v != undefined; });
                        // check if target cell is in the table.
                        if (targetCellInfo == undefined) {
                            return;
                        }
                        // check if the td can be expanded in bottom direction.
                        if (getBottom(targetCellInfo) >= this.rows) {
                            return;
                        }
                        // check merged cell collision.
                        var bottomLeftCellInfo = tableInfo[getBottom(targetCellInfo)][getLeft(targetCellInfo)];
                        var bottomRightCellInfo = tableInfo[getBottom(targetCellInfo)][getRight(targetCellInfo) - 1];
                        if (getLeft(bottomLeftCellInfo) < getLeft(targetCellInfo)) {
                            return;
                        }
                        if (getRight(bottomRightCellInfo) > getRight(targetCellInfo)) {
                            return;
                        }
                        // shrink next cells.
                        var shrinkRow = getBottom(targetCellInfo);
                        var insertPos = null;
                        if (shrinkRow < this.rows - 1) {
                            insertPos = getNextCell(tableInfo, shrinkRow + 1, getRight(targetCellInfo));
                        }
                        for (var c = getLeft(targetCellInfo); c < getRight(targetCellInfo);) {
                            var nextCellInfo = tableInfo[shrinkRow][c];
                            if (nextCellInfo.cell.rowSpan > 1) {
                                nextCellInfo.cell.remove();
                                nextCellInfo.cell.rowSpan--;
                                this.element.rows[shrinkRow + 1].insertBefore(nextCellInfo.cell, insertPos);
                            }
                            else {
                                nextCellInfo.cell.remove();
                            }
                            c += nextCellInfo.cell.colSpan;
                        }
                        // expand cell
                        this.targetTD.rowSpan++;
                    }
                };
                DeTable.prototype.shrinkRight = function () {
                    var _this = this;
                    if (this.targetTD) {
                        var tableInfo = this.getTableMergeInfo();
                        var targetCellInfo = tableInfo.map(function (v) { return v.find(function (v) { return v.cell == _this.targetTD; }); })
                            .find(function (v) { return v != undefined; });
                        // check if target cell is in the table.
                        if (targetCellInfo == undefined) {
                            return;
                        }
                        // check if the td can be shrinked.
                        if (targetCellInfo.cell.colSpan == 1) {
                            return;
                        }
                        // add new cells in right
                        for (var r = getTop(targetCellInfo); r < getBottom(targetCellInfo); r++) {
                            var insertPos = getNextCell(tableInfo, r, getRight(targetCellInfo));
                            var newCell = this.element.ownerDocument.createElement("td");
                            this.element.rows[r].insertBefore(newCell, insertPos);
                            de.common.addTag(newCell, "div");
                        }
                        // shrink cell
                        targetCellInfo.cell.colSpan--;
                    }
                };
                DeTable.prototype.shrinkBottom = function () {
                    var _this = this;
                    if (this.targetTD) {
                        var tableInfo = this.getTableMergeInfo();
                        var targetCellInfo = tableInfo.map(function (v) { return v.find(function (v) { return v.cell == _this.targetTD; }); })
                            .find(function (v) { return v != undefined; });
                        // check if target cell is in the table.
                        if (targetCellInfo == undefined) {
                            return;
                        }
                        // check if the td can be shrinked.
                        if (targetCellInfo.cell.rowSpan == 1) {
                            return;
                        }
                        // add new cells in bottom
                        var shrinkRow = getBottom(targetCellInfo) - 1;
                        var insertPos = getNextCell(tableInfo, shrinkRow, getRight(targetCellInfo));
                        for (var c = getLeft(targetCellInfo); c < getRight(targetCellInfo); c++) {
                            var newCell = this.element.ownerDocument.createElement("td");
                            this.element.rows[shrinkRow].insertBefore(newCell, insertPos);
                            de.common.addTag(newCell, "div");
                        }
                        // shrink cell
                        targetCellInfo.cell.rowSpan--;
                    }
                };
                return DeTable;
            }(element_14.DEEElementBase));
            element_14.DeTable = DeTable;
        })(element = de.element || (de.element = {}));
    })(de = ooo.de || (ooo.de = {}));
})(ooo || (ooo = {}));
var ooo;
(function (ooo) {
    var de;
    (function (de) {
        var element;
        (function (element) {
            var DEEPropertyBase = /** @class */ (function () {
                function DEEPropertyBase(parent, name, data) {
                    this.parent = parent;
                    this.name = name;
                    this.data = data;
                    this.children = [];
                    if (parent) {
                        parent.children.push(this);
                    }
                }
                DEEPropertyBase.prototype.getValue = function () {
                    for (var key in this.children) {
                        this.children[key].getValue();
                    }
                };
                DEEPropertyBase.prototype.setValue = function (data) {
                    for (var key in this.children) {
                        var prop = this.children[key];
                        if (prop) {
                            prop.setValue(data);
                        }
                    }
                };
                DEEPropertyBase.prototype.resetValue = function () {
                    this.setValue(this.data);
                };
                DEEPropertyBase.prototype.newLine = function () {
                    de.common.addTag(this.getBody(), "br");
                };
                return DEEPropertyBase;
            }());
            element.DEEPropertyBase = DEEPropertyBase;
            var DEEPropertyRoot = /** @class */ (function (_super) {
                __extends(DEEPropertyRoot, _super);
                function DEEPropertyRoot(pane, data) {
                    var _this = _super.call(this, undefined, "", data) || this;
                    _this.pane = pane;
                    _this.data = data;
                    return _this;
                }
                DEEPropertyRoot.prototype.getBody = function () {
                    return this.pane;
                };
                return DEEPropertyRoot;
            }(DEEPropertyBase));
            element.DEEPropertyRoot = DEEPropertyRoot;
            var DEEPropertyBox = /** @class */ (function (_super) {
                __extends(DEEPropertyBox, _super);
                function DEEPropertyBox(parent, caption) {
                    var _this = _super.call(this, parent, "", parent.data) || this;
                    _this.base = de.common.addTag(parent.getBody(), "div", "prop-base");
                    _this.header = de.common.addTag(_this.base, "div", "prop-header");
                    _this.body = de.common.addTag(_this.base, "div", "prop-body");
                    _this.header.innerHTML = caption;
                    var open = true;
                    var openButton = de.common.addButton(_this.header, "", function () {
                        open = !open;
                        if (open) {
                            _this.body.classList.remove("shrink");
                            openButton.classList.remove("shrink");
                        }
                        else {
                            _this.body.classList.add("shrink");
                            openButton.classList.add("shrink");
                        }
                    });
                    return _this;
                }
                DEEPropertyBox.prototype.getBody = function () {
                    return this.body;
                };
                return DEEPropertyBox;
            }(DEEPropertyBase));
            element.DEEPropertyBox = DEEPropertyBox;
            var DEEPropertyGroup = /** @class */ (function (_super) {
                __extends(DEEPropertyGroup, _super);
                function DEEPropertyGroup(parent, caption, description) {
                    var _this = _super.call(this, parent, "", parent.data) || this;
                    var div = de.common.addTag(parent.getBody(), "div", "property-name");
                    _this.body = de.common.addTag(parent.getBody(), "div", "prop-body");
                    div.innerText = caption;
                    if (description) {
                        div.title = description;
                    }
                    return _this;
                }
                DEEPropertyGroup.prototype.getBody = function () {
                    return this.body;
                };
                DEEPropertyGroup.prototype.show = function () {
                    this.body.hidden = false;
                };
                DEEPropertyGroup.prototype.hide = function () {
                    this.body.hidden = true;
                };
                return DEEPropertyGroup;
            }(DEEPropertyBase));
            element.DEEPropertyGroup = DEEPropertyGroup;
            var DEEPropertyItemInput = /** @class */ (function (_super) {
                __extends(DEEPropertyItemInput, _super);
                function DEEPropertyItemInput(parent, name, caption, description, onChange, type) {
                    var _this = this;
                    var _a;
                    _this = _super.call(this, parent, name, parent.data) || this;
                    _this.name = name;
                    var div = de.common.addTag(parent.getBody(), "div", "property-name");
                    div.innerText = caption !== null && caption !== void 0 ? caption : name;
                    if (description) {
                        div.title = description;
                    }
                    _this.input = de.common.addTag(parent.getBody(), "input");
                    _this.input.style.marginLeft = "10px";
                    _this.input.value = (_a = _this.data[name]) !== null && _a !== void 0 ? _a : "";
                    _this.input.addEventListener("change", function () {
                        _this.data[name] = _this.input.value;
                        if (onChange) {
                            onChange(_this.input.value);
                        }
                    });
                    if (type) {
                        _this.input.type = type;
                    }
                    return _this;
                }
                DEEPropertyItemInput.prototype.setValue = function (data) {
                    var _a;
                    this.input.value = (_a = data[this.name]) !== null && _a !== void 0 ? _a : (this.input.type == "color" ? "#FFFFFF" : "");
                };
                DEEPropertyItemInput.prototype.getValue = function () {
                    this.data[this.name] = this.input.value;
                };
                DEEPropertyItemInput.prototype.getBody = function () {
                    throw new Error("Method not implemented.");
                };
                return DEEPropertyItemInput;
            }(DEEPropertyBase));
            element.DEEPropertyItemInput = DEEPropertyItemInput;
            var DEEPropertyItemSelect = /** @class */ (function (_super) {
                __extends(DEEPropertyItemSelect, _super);
                function DEEPropertyItemSelect(parent, name, options, caption, description, onChange) {
                    var _this = this;
                    var _a;
                    _this = _super.call(this, parent, name, parent.data) || this;
                    _this.name = name;
                    var div = de.common.addTag(parent.getBody(), "div", "property-name");
                    div.innerText = caption !== null && caption !== void 0 ? caption : name;
                    if (description) {
                        div.title = description;
                    }
                    _this.select = de.common.addTag(parent.getBody(), "select");
                    _this.select.style.marginLeft = "10px";
                    _this.select.addEventListener("change", function () {
                        _this.data[name] = _this.select.value;
                        if (onChange) {
                            onChange(_this.select.value);
                        }
                    });
                    _this.setOptions(options);
                    if (description) {
                        div.title = description;
                    }
                    _this.select.value = _this.data ? (_a = _this.data[name]) !== null && _a !== void 0 ? _a : "" : "";
                    return _this;
                }
                DEEPropertyItemSelect.prototype.setValue = function (data) {
                    this.select.value = data[this.name];
                };
                DEEPropertyItemSelect.prototype.getValue = function () {
                    this.data[this.name] = this.select.value;
                };
                DEEPropertyItemSelect.prototype.getBody = function () {
                    throw new Error("Method not implemented.");
                };
                DEEPropertyItemSelect.prototype.setOptions = function (options) {
                    var previousValue = this.select.value;
                    this.select.options.length = 0;
                    for (var _i = 0, options_1 = options; _i < options_1.length; _i++) {
                        var option = options_1[_i];
                        var value = void 0;
                        var caption = void 0;
                        var tooltip = void 0;
                        if (typeof (option) == "string") {
                            value = option;
                            caption = option;
                            tooltip = option;
                        }
                        else {
                            value = option.value;
                            caption = option.caption;
                            tooltip = option.tooltip;
                        }
                        var optionElement = de.common.addTag(this.select, "option");
                        optionElement.value = value;
                        optionElement.title = tooltip;
                        optionElement.innerText = caption;
                    }
                    this.select.value = previousValue;
                };
                return DEEPropertyItemSelect;
            }(DEEPropertyBase));
            element.DEEPropertyItemSelect = DEEPropertyItemSelect;
            var DEEPropertyItemCheckBox = /** @class */ (function (_super) {
                __extends(DEEPropertyItemCheckBox, _super);
                function DEEPropertyItemCheckBox(parent, name, caption, description, onChange, setCheckBoxInRight) {
                    if (setCheckBoxInRight === void 0) { setCheckBoxInRight = false; }
                    var _this = _super.call(this, parent, name, parent.data) || this;
                    _this.name = name;
                    var div = de.common.addTag(parent.getBody(), "div");
                    _this.label = de.common.addTag(div, "label");
                    var addCheckBox = function () {
                        _this.input = de.common.addTag(_this.label, "input");
                        _this.input.type = "checkbox";
                        _this.input.addEventListener("change", function () {
                            _this.data[name] = _this.input.checked ? "1" : "0";
                            if (onChange) {
                                onChange(_this.input.checked);
                            }
                        });
                        _this.input.checked = _this.data[name] == "1";
                    };
                    var addSpan = function () {
                        var span = de.common.addTag(_this.label, "span");
                        span.innerText = caption !== null && caption !== void 0 ? caption : name;
                    };
                    if (setCheckBoxInRight) {
                        addSpan();
                        addCheckBox();
                    }
                    else {
                        addCheckBox();
                        addSpan();
                    }
                    if (description) {
                        div.title = description;
                    }
                    return _this;
                }
                DEEPropertyItemCheckBox.prototype.setValue = function (data) {
                    this.input.checked = (data[this.name] == "1");
                };
                DEEPropertyItemCheckBox.prototype.getValue = function () {
                    this.data[this.name] = this.input.checked ? "1" : "0";
                };
                DEEPropertyItemCheckBox.prototype.getBody = function () {
                    throw new Error("Method not implemented.");
                };
                return DEEPropertyItemCheckBox;
            }(DEEPropertyBase));
            element.DEEPropertyItemCheckBox = DEEPropertyItemCheckBox;
            var DEEPropertyItemButton = /** @class */ (function (_super) {
                __extends(DEEPropertyItemButton, _super);
                function DEEPropertyItemButton(parent, caption, icon, description, onClick) {
                    var _this = _super.call(this, parent, "", parent.data) || this;
                    _this.button = de.common.addButton(parent.getBody(), "button", function (ev) {
                        if (onClick) {
                            onClick(ev);
                        }
                    });
                    _this.button.innerText = caption;
                    _this.button.title = description !== null && description !== void 0 ? description : "";
                    if (icon) {
                        var img = de.common.addTag(_this.button, "img");
                        img.src = "../image/" + icon;
                    }
                    return _this;
                }
                DEEPropertyItemButton.prototype.setValue = function (data) { };
                DEEPropertyItemButton.prototype.getValue = function () { };
                DEEPropertyItemButton.prototype.getBody = function () {
                    throw new Error("Method not implemented.");
                };
                return DEEPropertyItemButton;
            }(DEEPropertyBase));
            element.DEEPropertyItemButton = DEEPropertyItemButton;
            var DEEPropertyItemDataTable = /** @class */ (function (_super) {
                __extends(DEEPropertyItemDataTable, _super);
                function DEEPropertyItemDataTable(parent, name, columns, caption, description, onChange) {
                    var _this = this;
                    var _a;
                    _this = _super.call(this, parent, name, parent.data) || this;
                    _this.name = name;
                    _this.columns = columns;
                    _this.onChange = onChange;
                    var div = de.common.addTag(parent.getBody(), "div", "property-name");
                    div.innerText = caption !== null && caption !== void 0 ? caption : name;
                    if (description) {
                        div.title = description;
                    }
                    _this.table = de.common.addTag(parent.getBody(), "table", "prop-datatable");
                    _this.table.style.marginLeft = "10px";
                    _this.thead = de.common.addTag(_this.table, "thead", "prop-head");
                    _this.tbody = de.common.addTag(_this.table, "tbody", "prop-body");
                    _this.tbody_add = de.common.addTag(_this.table, "tbody", "prop-body");
                    // set header
                    var _b = de.common.addTR(_this.thead, columns.length + 1), tds_headers = _b[1];
                    for (var i = 0; i < columns.length; i++) {
                        tds_headers[i + 1].innerText = (_a = columns[i].caption) !== null && _a !== void 0 ? _a : columns[i].name;
                        if (columns[i].description) {
                            tds_headers[i + 1].title = columns[i].description;
                        }
                    }
                    // set property
                    _this.setValue(_this.data);
                    // initial process
                    _this.addAddRow();
                    return _this;
                }
                // add new row event
                DEEPropertyItemDataTable.prototype.newRow = function () {
                    try {
                        var tr = this.tbody_add.firstChild;
                        this.tbody.insertBefore(tr, null);
                        this.setToolTD(tr);
                        this.addAddRow();
                    }
                    catch (ex) {
                        console.log("NG");
                    }
                };
                // set row to add
                DEEPropertyItemDataTable.prototype.addAddRow = function () {
                    var _this = this;
                    var _a = de.common.addTR(this.tbody_add, this.columns.length + 1), tr_add = _a[0], tds_add = _a[1];
                    var _loop_1 = function (i) {
                        var input = de.common.addTag(tds_add[i + 1], "input");
                        input.addEventListener("change", function () {
                            _this.onChangeInput(input);
                        });
                        input.addEventListener("keydown", function (ev) {
                            if (ev.key == "Enter") {
                                _this.onChangeInput(input);
                            }
                        });
                    };
                    for (var i = 0; i < this.columns.length; i++) {
                        _loop_1(i);
                    }
                };
                // on change item
                DEEPropertyItemDataTable.prototype.onChangeInput = function (input) {
                    var td = input.parentElement;
                    var tr = td.parentElement;
                    if (tr.parentElement == this.tbody_add) {
                        this.newRow();
                    }
                    this.getValue();
                    if (this.onChange) {
                        this.onChange();
                    }
                };
                // add tool cell
                DEEPropertyItemDataTable.prototype.setToolTD = function (tr) {
                    var _this = this;
                    var div = de.common.addTag(tr.firstChild, "div");
                    // up button
                    de.common.addImageButton(div, "../image/upArrow.svg", function () {
                        if (tr.rowIndex > 1) {
                            _this.tbody.insertBefore(tr, tr.previousSibling);
                        }
                        _this.getValue();
                        if (_this.onChange) {
                            _this.onChange();
                        }
                    });
                    // down button
                    de.common.addImageButton(div, "../image/downArrow.svg", function () {
                        if (tr.rowIndex < _this.tbody.rows.length) {
                            _this.tbody.insertBefore(tr, tr.nextElementSibling.nextElementSibling);
                        }
                        _this.getValue();
                        if (_this.onChange) {
                            _this.onChange();
                        }
                    });
                    // remove button
                    de.common.addImageButton(div, "../image/cross.svg", function () {
                        tr.remove();
                        _this.getValue();
                        if (_this.onChange) {
                            _this.onChange();
                        }
                    });
                };
                DEEPropertyItemDataTable.prototype.setValue = function (data) {
                    var _this = this;
                    var _a;
                    if (data[this.name]) {
                        var itemData = JSON.parse(data[this.name]);
                        this.tbody.innerHTML = "";
                        for (var _i = 0, itemData_1 = itemData; _i < itemData_1.length; _i++) {
                            var rowData = itemData_1[_i];
                            var _b = de.common.addTR(this.tbody, this.columns.length + 1), tr = _b[0], tds = _b[1];
                            this.setToolTD(tr);
                            var _loop_2 = function (i) {
                                var input = de.common.addTag(tds[i + 1], "input");
                                input.addEventListener("change", function () {
                                    _this.onChangeInput(input);
                                });
                                input.addEventListener("keydown", function (ev) {
                                    if (ev.key == "Enter") {
                                        _this.onChangeInput(input);
                                    }
                                });
                                input.value = (_a = rowData[this_1.columns[i].name]) !== null && _a !== void 0 ? _a : "";
                            };
                            var this_1 = this;
                            for (var i = 0; i < this.columns.length; i++) {
                                _loop_2(i);
                            }
                        }
                    }
                };
                DEEPropertyItemDataTable.prototype.getValue = function () {
                    this.data[this.name] = JSON.stringify(this.getData());
                };
                DEEPropertyItemDataTable.prototype.getData = function () {
                    var data = [];
                    for (var r = 0; r < this.tbody.rows.length; r++) {
                        var rowData = {};
                        data.push(rowData);
                        for (var c = 1; c < this.tbody.rows[r].cells.length; c++) {
                            rowData[this.columns[c - 1].name] = this.tbody.rows[r].cells[c].firstChild.value;
                        }
                    }
                    return data;
                };
                DEEPropertyItemDataTable.prototype.getBody = function () {
                    throw new Error("Method not implemented.");
                };
                return DEEPropertyItemDataTable;
            }(DEEPropertyBase));
            element.DEEPropertyItemDataTable = DEEPropertyItemDataTable;
            var DEEPropertyItemFile = /** @class */ (function (_super) {
                __extends(DEEPropertyItemFile, _super);
                function DEEPropertyItemFile(parent, name, caption, description, onChange, type) {
                    var _this = this;
                    var _a;
                    _this = _super.call(this, parent, name, parent.data) || this;
                    _this.name = name;
                    var div = de.common.addTag(parent.getBody(), "div", "property-name");
                    div.innerText = caption !== null && caption !== void 0 ? caption : name;
                    if (description) {
                        div.title = description;
                    }
                    _this.input = de.common.addTag(parent.getBody(), "input");
                    _this.input.style.marginLeft = "10px";
                    _this.input.value = (_a = _this.data[name]) !== null && _a !== void 0 ? _a : "";
                    _this.input.addEventListener("change", function () {
                        if (onChange) {
                            onChange(_this.input.value);
                        }
                    });
                    _this.input.type = "file";
                    if (type) {
                        _this.input.type = type;
                    }
                    return _this;
                }
                DEEPropertyItemFile.prototype.getValue = function () { };
                DEEPropertyItemFile.prototype.setValue = function (data) { };
                DEEPropertyItemFile.prototype.getBody = function () {
                    throw new Error("Method not implemented.");
                };
                return DEEPropertyItemFile;
            }(DEEPropertyBase));
            element.DEEPropertyItemFile = DEEPropertyItemFile;
        })(element = de.element || (de.element = {}));
    })(de = ooo.de || (ooo.de = {}));
})(ooo || (ooo = {}));
var ooo;
(function (ooo) {
    var de;
    (function (de) {
        var formatEditor;
        (function (formatEditor) {
            function init_datamanager() {
                var _this = this;
                var formatTableHead = document.getElementById("formatTableHead");
                var formatTableBody = document.getElementById("formatTableBody");
                var formatTableNew = document.getElementById("formatTableNew");
                var dataHead = document.getElementById("dataHead");
                var dataBody = document.getElementById("dataBody");
                makeFormatTable();
                var viewer = document.getElementById("viewer");
                var loadEndFunctions = [];
                viewer.addEventListener("load", function () {
                    viewer.contentWindow.addEventListener("message", function (ev) { return __awaiter(_this, void 0, void 0, function () {
                        var _i, loadEndFunctions_1, f;
                        return __generator(this, function (_a) {
                            switch (_a.label) {
                                case 0:
                                    if (!(ev.data == "load-end")) return [3 /*break*/, 5];
                                    _i = 0, loadEndFunctions_1 = loadEndFunctions;
                                    _a.label = 1;
                                case 1:
                                    if (!(_i < loadEndFunctions_1.length)) return [3 /*break*/, 4];
                                    f = loadEndFunctions_1[_i];
                                    return [4 /*yield*/, f()];
                                case 2:
                                    _a.sent();
                                    _a.label = 3;
                                case 3:
                                    _i++;
                                    return [3 /*break*/, 1];
                                case 4:
                                    loadEndFunctions.length = 0;
                                    _a.label = 5;
                                case 5: return [2 /*return*/];
                            }
                        });
                    }); });
                });
                function makeFormatTable() {
                    return __awaiter(this, void 0, void 0, function () {
                        var _a, _b, h_item, list, _loop_3, _i, list_1, item;
                        var _this = this;
                        return __generator(this, function (_c) {
                            switch (_c.label) {
                                case 0:
                                    formatTableHead.innerHTML = "";
                                    formatTableBody.innerHTML = "";
                                    _a = de.common.addTR(formatTableHead, 2), _b = _a[1], h_item = _b[1];
                                    h_item.innerText = "Format/Schema";
                                    return [4 /*yield*/, de.common.postJson("".concat(de.common.COMMAND_PATH, "/format/list/"))];
                                case 1:
                                    list = _c.sent();
                                    _loop_3 = function (item) {
                                        var format = item.substring(0, item.length - 4);
                                        var _d = de.common.addTR(formatTableBody, 2), _e = _d[1], d_tool = _e[0], d_item = _e[1];
                                        d_item.innerText = format;
                                        // open button
                                        de.common.addImageButton(d_tool, "../image/edit.svg", function () { return __awaiter(_this, void 0, void 0, function () {
                                            return __generator(this, function (_a) {
                                                window.open("./formatEditor.html?format=".concat(format));
                                                return [2 /*return*/];
                                            });
                                        }); });
                                        // view button
                                        de.common.addImageButton(d_tool, "../image/view.svg", function () { return __awaiter(_this, void 0, void 0, function () {
                                            return __generator(this, function (_a) {
                                                viewFormat(format);
                                                return [2 /*return*/];
                                            });
                                        }); });
                                    };
                                    for (_i = 0, list_1 = list; _i < list_1.length; _i++) {
                                        item = list_1[_i];
                                        _loop_3(item);
                                    }
                                    return [2 /*return*/];
                            }
                        });
                    });
                }
                function viewFormat(format) {
                    return __awaiter(this, void 0, void 0, function () {
                        var viewer;
                        var _this = this;
                        return __generator(this, function (_a) {
                            dataHead.innerHTML = "";
                            dataBody.innerHTML = "";
                            viewer = document.getElementById("viewer");
                            viewer.src = "./viewer.html?format=".concat(format);
                            loadEndFunctions.push(function () { return __awaiter(_this, void 0, void 0, function () {
                                var commonInfo, schemaName, dataList, headerList, _i, dataList_2, doc, name_1, _a, _b, h_id, h_items, i, _loop_4, _c, dataList_3, doc, ex_2;
                                var _this = this;
                                var _d, _e, _f;
                                return __generator(this, function (_g) {
                                    switch (_g.label) {
                                        case 0:
                                            _g.trys.push([0, 2, , 3]);
                                            commonInfo = (_d = viewer.contentDocument) === null || _d === void 0 ? void 0 : _d.getElementById(formatEditor.META_INFO_TAG_ID);
                                            schemaName = void 0;
                                            if (commonInfo && (commonInfo === null || commonInfo === void 0 ? void 0 : commonInfo.dataset.de_makeSchema) === "1") {
                                                schemaName = (_e = commonInfo === null || commonInfo === void 0 ? void 0 : commonInfo.dataset.de_schemaName) !== null && _e !== void 0 ? _e : format;
                                            }
                                            else {
                                                schemaName = format;
                                            }
                                            document.getElementById("schema-name").innerText = schemaName;
                                            dataHead.innerHTML = "";
                                            dataBody.innerHTML = "";
                                            return [4 /*yield*/, de.common.postJson("".concat(de.common.COMMAND_PATH, "/doc/").concat(schemaName, "/getAll"))];
                                        case 1:
                                            dataList = _g.sent();
                                            if (dataList.length == 0) {
                                                return [2 /*return*/];
                                            }
                                            headerList = [];
                                            for (_i = 0, dataList_2 = dataList; _i < dataList_2.length; _i++) {
                                                doc = dataList_2[_i];
                                                for (name_1 in doc.data) {
                                                    if (headerList.indexOf(name_1) == -1) {
                                                        headerList.push(name_1);
                                                    }
                                                }
                                            }
                                            _a = de.common.addTR(dataHead, headerList.length + 2), _b = _a[1], h_id = _b[1], h_items = _b.slice(2);
                                            h_id.innerText = "ID";
                                            for (i = 0; i < headerList.length; i++) {
                                                h_items[i].innerText = headerList[i];
                                            }
                                            _loop_4 = function (doc) {
                                                var _h = de.common.addTR(dataBody, headerList.length + 2), _j = _h[1], d_tool = _j[0], d_id = _j[1], d_items = _j.slice(2);
                                                // ID
                                                d_id.innerText = doc.id;
                                                // data
                                                for (var i = 0; i < headerList.length; i++) {
                                                    d_items[i].innerText = (_f = doc.data[headerList[i]]) !== null && _f !== void 0 ? _f : "";
                                                }
                                                // edit button
                                                de.common.addImageButton(d_tool, "../image/edit.svg", function () { return __awaiter(_this, void 0, void 0, function () {
                                                    return __generator(this, function (_a) {
                                                        window.open("./viewer.html?format=".concat(format, "&id=").concat(doc.id));
                                                        return [2 /*return*/];
                                                    });
                                                }); });
                                                // view button
                                                de.common.addImageButton(d_tool, "../image/open.svg", function () { return __awaiter(_this, void 0, void 0, function () {
                                                    return __generator(this, function (_a) {
                                                        window.open("./viewer.html?format=".concat(format, "&id=").concat(doc.id, "&readonly=1"));
                                                        return [2 /*return*/];
                                                    });
                                                }); });
                                                // view button
                                                de.common.addImageButton(d_tool, "../image/view.svg", function () { return __awaiter(_this, void 0, void 0, function () {
                                                    var viewer;
                                                    return __generator(this, function (_a) {
                                                        viewer = document.getElementById("viewer");
                                                        viewer.src = "./viewer.html?format=".concat(format, "&id=").concat(doc.id, "&readonly=1");
                                                        return [2 /*return*/];
                                                    });
                                                }); });
                                            };
                                            // body
                                            for (_c = 0, dataList_3 = dataList; _c < dataList_3.length; _c++) {
                                                doc = dataList_3[_c];
                                                _loop_4(doc);
                                            }
                                            return [3 /*break*/, 3];
                                        case 2:
                                            ex_2 = _g.sent();
                                            return [3 /*break*/, 3];
                                        case 3: return [2 /*return*/];
                                    }
                                });
                            }); });
                            return [2 /*return*/];
                        });
                    });
                }
                formatTableNew.addEventListener("click", function () {
                    open("./formatEditor.html");
                });
            }
            formatEditor.init_datamanager = init_datamanager;
        })(formatEditor = de.formatEditor || (de.formatEditor = {}));
    })(de = ooo.de || (ooo.de = {}));
})(ooo || (ooo = {}));
var ooo;
(function (ooo) {
    var de;
    (function (de) {
        var formatEditor;
        (function (formatEditor) {
            function showSaveDialog(ev) {
                var _this = this;
                var _a = ooo.de.common.modal(), base = _a[0], back = _a[1];
                // Adjust window position
                {
                    base.style.top = ev.clientY + ".px";
                    base.style.left = ev.clientX + ".px";
                    var clientRect = base.getBoundingClientRect();
                    if (clientRect.left < 0) {
                        base.style.left = "0px";
                    }
                    else if (clientRect.right >= window.innerWidth) {
                        base.style.left = (window.innerWidth - clientRect.width) + "px";
                    }
                    if (clientRect.top < 0) {
                        base.style.top = "0px";
                    }
                    else if (clientRect.bottom >= window.innerHeight) {
                        base.style.top = (window.innerHeight - clientRect.height) + "px";
                    }
                }
                de.common.addTextDiv(base, "Format Name");
                var input = de.common.addTag(base, "input");
                input.placeholder = "Format Name";
                input.value = formatEditor.formatProperty.formatName || "";
                input.focus();
                var execSave = function () { return __awaiter(_this, void 0, void 0, function () {
                    var ex_3;
                    return __generator(this, function (_a) {
                        switch (_a.label) {
                            case 0:
                                _a.trys.push([0, 2, , 3]);
                                return [4 /*yield*/, save(input.value)];
                            case 1:
                                _a.sent();
                                back.remove();
                                return [3 /*break*/, 3];
                            case 2:
                                ex_3 = _a.sent();
                                console.error(ex_3);
                                return [3 /*break*/, 3];
                            case 3: return [2 /*return*/];
                        }
                    });
                }); };
                de.common.addButton(base, "Save", execSave);
                input.addEventListener("keypress", function (ev) {
                    if (ev.key == "Enter") {
                        execSave();
                    }
                });
            }
            formatEditor.showSaveDialog = showSaveDialog;
            function save(formatName) {
                return __awaiter(this, void 0, void 0, function () {
                    var _i, _a, elem, metaInfo, formatBody, html, schemaName, ex_4;
                    return __generator(this, function (_b) {
                        switch (_b.label) {
                            case 0:
                                // Save Format
                                for (_i = 0, _a = de.element.DEEElementBase.elementList; _i < _a.length; _i++) {
                                    elem = _a[_i];
                                    elem.objectToDataset();
                                }
                                {
                                    metaInfo = document.getElementById(formatEditor.META_INFO_TAG_ID);
                                    if (!metaInfo) {
                                        formatBody = document.getElementById("formatBody");
                                        metaInfo = de.common.addTag(formatBody, "div");
                                        metaInfo.id = formatEditor.META_INFO_TAG_ID;
                                        metaInfo.contentEditable = "false";
                                    }
                                    de.common.objectToDataset(metaInfo, formatEditor.formatProperty);
                                }
                                html = document.getElementById("formatBody").innerHTML;
                                try {
                                    de.common.post("".concat(de.common.COMMAND_PATH, "/format/save/").concat(formatName), html, de.common.HH_CT_TEXT);
                                }
                                catch (ex) {
                                    console.error(ex);
                                }
                                if (!(formatEditor.formatProperty.makeSchema == "1")) return [3 /*break*/, 4];
                                _b.label = 1;
                            case 1:
                                _b.trys.push([1, 3, , 4]);
                                schemaName = formatEditor.formatProperty.schemaName || formatName;
                                return [4 /*yield*/, de.common.post("".concat(de.common.COMMAND_PATH, "/schema/save/").concat(schemaName), JSON.stringify(formatEditor.getSchema()), de.common.HH_CT_JSON)];
                            case 2:
                                _b.sent();
                                return [3 /*break*/, 4];
                            case 3:
                                ex_4 = _b.sent();
                                console.error(ex_4);
                                return [3 /*break*/, 4];
                            case 4: return [2 /*return*/];
                        }
                    });
                });
            }
            formatEditor.save = save;
            function showLoadDialog(ev) {
                return __awaiter(this, void 0, void 0, function () {
                    var _a, base, back, clientRect, listDiv, list, selectedItem, selectedFormatName, _loop_5, _i, list_2, name_2, loadButton;
                    var _this = this;
                    return __generator(this, function (_b) {
                        switch (_b.label) {
                            case 0:
                                _a = ooo.de.common.modal(), base = _a[0], back = _a[1];
                                // Adjust window position
                                {
                                    base.style.top = ev.clientY + ".px";
                                    base.style.left = ev.clientX + ".px";
                                    clientRect = base.getBoundingClientRect();
                                    if (clientRect.left < 0) {
                                        base.style.left = "0px";
                                    }
                                    else if (clientRect.right >= window.innerWidth) {
                                        base.style.left = (window.innerWidth - clientRect.width) + "px";
                                    }
                                    if (clientRect.top < 0) {
                                        base.style.top = "0px";
                                    }
                                    else if (clientRect.bottom >= window.innerHeight) {
                                        base.style.top = (window.innerHeight - clientRect.height) + "px";
                                    }
                                }
                                de.common.addTextDiv(base, "Format List");
                                listDiv = de.common.addTag(base, "div");
                                return [4 /*yield*/, de.common.postJson("".concat(de.common.COMMAND_PATH, "/format/list/all"))];
                            case 1:
                                list = _b.sent();
                                selectedItem = undefined;
                                selectedFormatName = "";
                                _loop_5 = function (name_2) {
                                    var formatName = name_2.substring(0, name_2.length - 4);
                                    var listItem = de.common.addTextDiv(base, formatName, "menu-item");
                                    listItem.addEventListener("click", function () {
                                        if (selectedItem) {
                                            selectedItem.classList.remove("selected");
                                        }
                                        listItem.classList.add("selected");
                                        selectedItem = listItem;
                                        selectedFormatName = formatName;
                                        loadButton.disabled = false;
                                    });
                                    listItem.addEventListener("dblclick", function () { return __awaiter(_this, void 0, void 0, function () {
                                        var ex_5;
                                        return __generator(this, function (_a) {
                                            switch (_a.label) {
                                                case 0:
                                                    _a.trys.push([0, 2, , 3]);
                                                    return [4 /*yield*/, load(formatName)];
                                                case 1:
                                                    _a.sent();
                                                    back.remove();
                                                    return [3 /*break*/, 3];
                                                case 2:
                                                    ex_5 = _a.sent();
                                                    console.error(ex_5);
                                                    return [3 /*break*/, 3];
                                                case 3: return [2 /*return*/];
                                            }
                                        });
                                    }); });
                                };
                                for (_i = 0, list_2 = list; _i < list_2.length; _i++) {
                                    name_2 = list_2[_i];
                                    _loop_5(name_2);
                                }
                                loadButton = de.common.addButton(base, "Load", function () { return __awaiter(_this, void 0, void 0, function () {
                                    var ex_6;
                                    return __generator(this, function (_a) {
                                        switch (_a.label) {
                                            case 0:
                                                _a.trys.push([0, 2, , 3]);
                                                return [4 /*yield*/, load(selectedFormatName)];
                                            case 1:
                                                _a.sent();
                                                back.remove();
                                                return [3 /*break*/, 3];
                                            case 2:
                                                ex_6 = _a.sent();
                                                console.error(ex_6);
                                                return [3 /*break*/, 3];
                                            case 3: return [2 /*return*/];
                                        }
                                    });
                                }); });
                                loadButton.disabled = true;
                                return [2 /*return*/];
                        }
                    });
                });
            }
            formatEditor.showLoadDialog = showLoadDialog;
            function load(formatName) {
                var _a;
                return __awaiter(this, void 0, void 0, function () {
                    var data, formatBody, metaInfo, elements, schemaName;
                    return __generator(this, function (_b) {
                        switch (_b.label) {
                            case 0: return [4 /*yield*/, de.common.post("".concat(de.common.COMMAND_PATH, "/format/load/").concat(formatName))];
                            case 1:
                                data = _b.sent();
                                formatBody = document.getElementById("formatBody");
                                formatBody.innerHTML = data;
                                formatEditor.formatProperty = {};
                                {
                                    metaInfo = document.getElementById(formatEditor.META_INFO_TAG_ID);
                                    if (metaInfo) {
                                        de.common.datasetToObject(metaInfo, formatEditor.formatProperty);
                                    }
                                    else {
                                        formatEditor.formatProperty.formatName = formatName;
                                    }
                                }
                                // clear elements
                                de.element.DEEElementBase.elementList.length = 0;
                                elements = formatBody.querySelectorAll("*[data-deid]");
                                elements.forEach(function (element) {
                                    if (element instanceof HTMLElement) {
                                        formatEditor.loadElement(element);
                                    }
                                });
                                if (!((formatEditor.formatProperty === null || formatEditor.formatProperty === void 0 ? void 0 : formatEditor.formatProperty.makeSchema) == "1")) return [3 /*break*/, 3];
                                schemaName = (_a = formatEditor.formatProperty.schemaName) !== null && _a !== void 0 ? _a : formatEditor.formatProperty.formatName;
                                return [4 /*yield*/, de.common.postJson("".concat(de.common.COMMAND_PATH, "/schema/load/").concat(schemaName))];
                            case 2:
                                formatEditor.schema = _b.sent();
                                _b.label = 3;
                            case 3:
                                formatEditor.setFormProperty();
                                return [2 /*return*/];
                        }
                    });
                });
            }
            formatEditor.load = load;
        })(formatEditor = de.formatEditor || (de.formatEditor = {}));
    })(de = ooo.de || (ooo.de = {}));
})(ooo || (ooo = {}));
var ooo;
(function (ooo) {
    var de;
    (function (de) {
        var formatEditor;
        (function (formatEditor) {
            formatEditor.formatProperty = {};
            var formatPropertyList = [];
            function setFormProperty() {
                for (var _i = 0, formatPropertyList_1 = formatPropertyList; _i < formatPropertyList_1.length; _i++) {
                    var e = formatPropertyList_1[_i];
                    e.setValue(formatEditor.formatProperty);
                }
            }
            formatEditor.setFormProperty = setFormProperty;
            function initFormatProperty() {
                return __awaiter(this, void 0, void 0, function () {
                    var commonInfoView, root, boxFormatInfo, formatName, makeSchema, schemaGroup, schemaName, idProperty, updateIdProp;
                    return __generator(this, function (_a) {
                        commonInfoView = document.getElementById("commonInfoView");
                        root = new de.element.DEEPropertyRoot(commonInfoView, formatEditor.formatProperty);
                        boxFormatInfo = new de.element.DEEPropertyBox(root, "Format Information");
                        // Save/Load
                        new de.element.DEEPropertyItemButton(boxFormatInfo, "", "../image/save.svg", "Save format.", formatEditor.showSaveDialog);
                        new de.element.DEEPropertyItemButton(boxFormatInfo, "", "../image/load.svg", "Load format.", formatEditor.showLoadDialog);
                        new de.element.DEEPropertyItemButton(boxFormatInfo, "", "../image/view.svg", "View format.", function () {
                            if (formatEditor.formatProperty.formatName) {
                                window.open("./viewer.html?format=".concat(formatEditor.formatProperty.formatName));
                            }
                        });
                        new de.element.DEEPropertyItemButton(boxFormatInfo, "", "../image/html.svg", "Save format.", formatEditor.showLoadHTMLDialog);
                        formatName = new de.element.DEEPropertyItemInput(boxFormatInfo, "formatName", "Format Name", "Name of the format.");
                        formatPropertyList.push(formatName);
                        makeSchema = new de.element.DEEPropertyItemCheckBox(boxFormatInfo, "makeSchema", "Make schema", "If you want to make schema of this format, please check this.", function (v) {
                            if (v) {
                                schemaGroup.show();
                            }
                            else {
                                schemaGroup.hide();
                            }
                        }, true);
                        formatPropertyList.push(makeSchema);
                        schemaGroup = new de.element.DEEPropertyGroup(boxFormatInfo, "", "Schema Information");
                        schemaGroup.hide();
                        schemaName = new de.element.DEEPropertyItemInput(schemaGroup, "schemaName", "Schema name", "Set schema name. If empty, schema name is format name.");
                        formatPropertyList.push(schemaName);
                        idProperty = new de.element.DEEPropertyItemSelect(boxFormatInfo, "idProperty", [], "Document ID property", "Set id property name. If empty, ID is random value.");
                        {
                            updateIdProp = function () {
                                formatEditor.elementListUpdate();
                                idProperty.setOptions(__spreadArray([""], propertyNameList(), true));
                            };
                            idProperty.select.addEventListener("click", updateIdProp);
                            idProperty.select.addEventListener("key", updateIdProp);
                        }
                        formatPropertyList.push(idProperty);
                        return [2 /*return*/];
                    });
                });
            }
            formatEditor.initFormatProperty = initFormatProperty;
            function propertyNameList() {
                return de.element.DEEElementBase.elementList.map(function (v) { return v.properties.name; }).filter(function (v, i, arr) { return v && arr.indexOf(v) == i; });
            }
            ;
            function getSchema() {
                var schema = {};
                for (var _i = 0, _a = de.element.DEEElementBase.elementList; _i < _a.length; _i++) {
                    var elem = _a[_i];
                    elem.getSchema(schema);
                }
                return schema;
            }
            formatEditor.getSchema = getSchema;
        })(formatEditor = de.formatEditor || (de.formatEditor = {}));
    })(de = ooo.de || (ooo.de = {}));
})(ooo || (ooo = {}));
var ooo;
(function (ooo) {
    var de;
    (function (de) {
        var formatEditor;
        (function (formatEditor) {
            formatEditor.META_INFO_TAG_ID = "ooo_de_meta_tag";
            formatEditor.DeeList = [];
            //#region Common
            /**
             * Add new DEEBase element.
             * @param factory New DEEBase element.
             */
            function AddDEE(factory, parent) {
                formatEditor.DeeList.push(factory);
                if (formatEditor.pageMode == "format") {
                    var formatBody_1 = document.getElementById("formatBody");
                    factory.makeToolButton(de.common.addButton(parent, "", function () {
                        var selection = document.getSelection();
                        if (selection && selection.rangeCount > 0) {
                            var target = selection.getRangeAt(0).startContainer;
                            if (de.common.checkIsChild(formatBody_1, target)) {
                                var dee = factory.createElement(selection.getRangeAt(0));
                                var id = de.common.newID();
                                dee.id = id;
                                dee.element.dataset.deid = id;
                                dee.element.dataset.detype = factory.getType();
                                setOnClickElementEvent(dee);
                                activate(dee);
                                dee.onAfterCreate();
                            }
                        }
                    }, "toolbutton"));
                }
            }
            function AddSystemDEE() {
                var toolbarData = document.getElementById("toolbar-data");
                var toolbarOthers = document.getElementById("toolbar-others");
                // Data elements
                AddDEE(new de.element.DeInputFactory(), toolbarData);
                AddDEE(new de.element.DeSelectFactory(), toolbarData);
                AddDEE(new de.element.DeRadioFactory(), toolbarData);
                AddDEE(new de.element.DeFileFactory(), toolbarData);
                AddDEE(new de.element.DeInputExFactory("date", "Date"), toolbarData);
                AddDEE(new de.element.DeInputExFactory("number", "Number"), toolbarData);
                AddDEE(new de.element.DeInputExFactory("color", "Color"), toolbarData);
                // Other elements
                AddDEE(new de.element.DeLinkFactory(), toolbarOthers);
                AddDEE(new de.element.DeCommandButtonFactory(), toolbarOthers);
                AddDEE(new de.element.DeTableFactory(), toolbarOthers);
                AddDEE(new de.element.DeDataViewFactory(), toolbarOthers);
                AddDEE(new de.element.DeImageFactory(), toolbarOthers);
            }
            //#endregion
            //#region Make Format
            function init_format() {
                formatEditor.pageMode = "format";
                AddSystemDEE();
                de.element.DEEFactroyBase.onActive = activate;
                makePropertyTab();
                formatEditor.initFormatProperty();
                formatEditor.initStyleView();
                params = urlArgs();
                if (params.format) {
                    formatEditor.load(params.format);
                }
            }
            formatEditor.init_format = init_format;
            var activeProperty;
            function activate(element) {
                var propertyView = document.getElementById("propertyView");
                if (activeProperty != element.id) {
                    propertyView.innerHTML = "";
                    element.showProperty(propertyView);
                }
            }
            formatEditor.activate = activate;
            function makePropertyTab() {
                var parent = document.getElementById("propertyViewPane");
                var propertyTab = new de.common.TabView(parent, [{
                        caption: "Format",
                        name: "format",
                        htmlID: "commonInfoView"
                    }, {
                        caption: "Data",
                        name: "data"
                    }, {
                        caption: "Style",
                        name: "style",
                        htmlID: "styleView"
                    }]);
                var elementSelectArea = de.common.addTag(propertyTab.getTabItem("data"), "div");
                var propertyArea = de.common.addTag(propertyTab.getTabItem("data"), "div");
                propertyArea.id = "propertyView";
                // Element List
                var elementsSelectRoot = new de.element.DEEPropertyRoot(elementSelectArea, {});
                var elementsSelect = new de.element.DEEPropertyItemSelect(elementsSelectRoot, "activeElement", [], "Elements", "Element list in this form.", function (v) {
                    var target = de.element.DEEElementBase.elementList.find(function (e) { return e.id == v; });
                    if (target) {
                        activate(target);
                    }
                });
                elementsSelect.select.addEventListener("click", update);
                elementsSelect.select.addEventListener("keydown", update);
                elementsSelect.select.addEventListener("change", function () {
                    var id = elementsSelect.select.value;
                    var target = de.element.DEEElementBase.elementList.find(function (e) { return e.id == id; });
                    if (target) {
                        activate(target);
                    }
                });
                function update() {
                    return __awaiter(this, void 0, void 0, function () {
                        return __generator(this, function (_a) {
                            elementListUpdate();
                            elementsSelect.setOptions(de.element.DEEElementBase.elementList.map(function (e) {
                                return {
                                    value: e.id,
                                    caption: e.properties.name || e.id,
                                    tooltip: e.properties.description || e.properties.name || e.id
                                };
                            }));
                            return [2 /*return*/];
                        });
                    });
                }
            }
            function elementListUpdate() {
                var formBody = document.getElementById("formatBody");
                for (var i = 0; i < de.element.DEEElementBase.elementList.length;) {
                    var e = de.element.DEEElementBase.elementList[i];
                    if (!formBody.querySelector("*[data-deid=\"".concat(e.id, "\"]"))) {
                        de.element.DEEElementBase.elementList.splice(i, 1);
                    }
                    else {
                        i++;
                    }
                }
            }
            formatEditor.elementListUpdate = elementListUpdate;
            //#endregion
            //#region View
            function urlArgs() {
                var ret = {};
                var searchString = location.search.replace("?", "");
                for (var _i = 0, _a = searchString.split("&").map(function (v) { return v.split("=").map(function (a) { return decodeURIComponent(a); }); }); _i < _a.length; _i++) {
                    var _b = _a[_i], key = _b[0], value = _b[1];
                    ret[key] = value;
                }
                return ret;
            }
            var params;
            function init_viewer() {
                return __awaiter(this, void 0, void 0, function () {
                    var schemaName, metaInfo, data, _i, _a, elem, ex_7;
                    return __generator(this, function (_b) {
                        switch (_b.label) {
                            case 0:
                                params = urlArgs();
                                formatEditor.pageMode = "view";
                                AddSystemDEE();
                                de.element.DEEFactroyBase.onActive = function () { };
                                return [4 /*yield*/, formatEditor.load(params.format)];
                            case 1:
                                _b.sent();
                                {
                                    metaInfo = document.getElementById(formatEditor.META_INFO_TAG_ID);
                                    if (metaInfo && metaInfo.dataset.de_makeSchema == "1") {
                                        schemaName = metaInfo.dataset.de_schemaName || params.format;
                                    }
                                    else {
                                        schemaName = params.format;
                                    }
                                }
                                if (!params.id) return [3 /*break*/, 5];
                                _b.label = 2;
                            case 2:
                                _b.trys.push([2, 4, , 5]);
                                return [4 /*yield*/, de.common.postJson("".concat(de.common.COMMAND_PATH, "/doc/").concat(schemaName, "/load/").concat(params.id))];
                            case 3:
                                data = _b.sent();
                                for (_i = 0, _a = de.element.DEEElementBase.elementList; _i < _a.length; _i++) {
                                    elem = _a[_i];
                                    if (elem.properties.name) {
                                        elem.setFormData(data);
                                    }
                                    if (params.readonly) {
                                        elem.setReadonly();
                                    }
                                }
                                return [3 /*break*/, 5];
                            case 4:
                                ex_7 = _b.sent();
                                console.error(ex_7);
                                return [3 /*break*/, 5];
                            case 5:
                                postMessage("load-end");
                                return [2 /*return*/];
                        }
                    });
                });
            }
            formatEditor.init_viewer = init_viewer;
            function setOnClickElementEvent(dee) {
                switch (formatEditor.pageMode) {
                    case "format":
                        {
                            dee.element.addEventListener("click", function (ev) {
                                if (ev.target instanceof HTMLElement &&
                                    ev.target.closest("*[data-detype]") == dee.element) {
                                    dee.onClickFormatMode(ev);
                                }
                            });
                        }
                        break;
                    case "view":
                        {
                            dee.element.addEventListener("click", function (ev) {
                                if (ev.target instanceof HTMLElement &&
                                    ev.target.closest("*[data-detype]") == dee.element) {
                                    dee.onClickViewMode(ev);
                                }
                            });
                        }
                        break;
                }
            }
            formatEditor.setOnClickElementEvent = setOnClickElementEvent;
            function submit() {
                var _a;
                return __awaiter(this, void 0, void 0, function () {
                    var properties, _i, _b, elem, schemaName, id, ex_8;
                    return __generator(this, function (_c) {
                        switch (_c.label) {
                            case 0:
                                properties = {};
                                _i = 0, _b = de.element.DEEElementBase.elementList;
                                _c.label = 1;
                            case 1:
                                if (!(_i < _b.length)) return [3 /*break*/, 4];
                                elem = _b[_i];
                                return [4 /*yield*/, elem.getFormData(properties)];
                            case 2:
                                _c.sent();
                                _c.label = 3;
                            case 3:
                                _i++;
                                return [3 /*break*/, 1];
                            case 4:
                                schemaName = (_a = formatEditor.formatProperty.schemaName) !== null && _a !== void 0 ? _a : params.format;
                                id = undefined;
                                if (formatEditor.formatProperty.idProperty) {
                                    id = properties[formatEditor.formatProperty.idProperty];
                                }
                                else if (params.id) {
                                    id = params.id;
                                }
                                _c.label = 5;
                            case 5:
                                _c.trys.push([5, 10, , 11]);
                                if (!id) return [3 /*break*/, 7];
                                return [4 /*yield*/, de.common.post("".concat(de.common.COMMAND_PATH, "/doc/").concat(schemaName, "/update/").concat(id), JSON.stringify(properties), de.common.HH_CT_JSON)];
                            case 6:
                                _c.sent();
                                return [3 /*break*/, 9];
                            case 7: return [4 /*yield*/, de.common.post("".concat(de.common.COMMAND_PATH, "/doc/").concat(schemaName, "/create/"), JSON.stringify(properties), de.common.HH_CT_JSON)];
                            case 8:
                                _c.sent();
                                _c.label = 9;
                            case 9: return [3 /*break*/, 11];
                            case 10:
                                ex_8 = _c.sent();
                                console.error(ex_8);
                                return [3 /*break*/, 11];
                            case 11: return [2 /*return*/];
                        }
                    });
                });
            }
            formatEditor.submit = submit;
            function clear() {
                for (var _i = 0, _a = de.element.DEEElementBase.elementList; _i < _a.length; _i++) {
                    var elem = _a[_i];
                    elem.setFormData({});
                }
            }
            formatEditor.clear = clear;
            function showLoadHTMLDialog(ev) {
                var _this = this;
                var _a = ooo.de.common.modal(), base = _a[0], back = _a[1];
                de.common.addTextDiv(base, "HTML File");
                var input = de.common.addTag(base, "input");
                input.placeholder = "Select HTML file";
                input.type = "file";
                input.focus();
                var exec = function () { return __awaiter(_this, void 0, void 0, function () {
                    var ex_9;
                    return __generator(this, function (_a) {
                        switch (_a.label) {
                            case 0:
                                _a.trys.push([0, 3, , 4]);
                                if (!(input.files && input.files.length > 0)) return [3 /*break*/, 2];
                                return [4 /*yield*/, loadHTML(input.files[0])];
                            case 1:
                                _a.sent();
                                back.remove();
                                _a.label = 2;
                            case 2: return [3 /*break*/, 4];
                            case 3:
                                ex_9 = _a.sent();
                                console.error(ex_9);
                                return [3 /*break*/, 4];
                            case 4: return [2 /*return*/];
                        }
                    });
                }); };
                de.common.addButton(base, "Load", exec);
                input.addEventListener("keypress", function (ev) {
                    if (ev.key == "Enter") {
                        exec();
                    }
                });
                // Adjust window position
                {
                    base.style.top = ev.clientY + ".px";
                    base.style.left = ev.clientX + ".px";
                    var clientRect = base.getBoundingClientRect();
                    if (clientRect.left < 0) {
                        base.style.left = "0px";
                    }
                    else if (clientRect.right >= window.innerWidth) {
                        base.style.left = (window.innerWidth - clientRect.width) + "px";
                    }
                    if (clientRect.top < 0) {
                        base.style.top = "0px";
                    }
                    else if (clientRect.bottom >= window.innerHeight) {
                        base.style.top = (window.innerHeight - clientRect.height) + "px";
                    }
                }
            }
            formatEditor.showLoadHTMLDialog = showLoadHTMLDialog;
            function loadHTML(file) {
                return __awaiter(this, void 0, void 0, function () {
                    var formatBody, byteArray, htmlString, htmlDoc, headerElements, i, modifiedHtmlString;
                    return __generator(this, function (_a) {
                        switch (_a.label) {
                            case 0:
                                formatBody = document.getElementById("formatBody");
                                formatEditor.formatProperty = {};
                                return [4 /*yield*/, file.arrayBuffer()];
                            case 1:
                                byteArray = _a.sent();
                                htmlString = de.common.ArrayBufferToString(byteArray);
                                htmlDoc = new DOMParser().parseFromString(htmlString, 'text/html');
                                headerElements = htmlDoc.head.querySelectorAll("link,style");
                                for (i = 0; i < headerElements.length; i++) {
                                    htmlDoc.body.innerHTML += headerElements[i].outerHTML;
                                }
                                modifiedHtmlString = htmlDoc.body.innerHTML;
                                formatBody.innerHTML = modifiedHtmlString;
                                return [2 /*return*/];
                        }
                    });
                });
            }
            function loadElement(element) {
                var defactory = formatEditor.DeeList.find(function (e) { return e.getType() == element.dataset.detype; });
                if (defactory) {
                    var dee = defactory.loadElement(element);
                    dee.id = element.dataset.deid;
                    setOnClickElementEvent(dee);
                }
            }
            formatEditor.loadElement = loadElement;
            function refreshElements() {
                var formatBody = document.getElementById("formatBody");
                var htmlElements = formatBody.querySelectorAll("*[data-deid]");
                // Remove deleted element
                for (var i = 0; i < de.element.DEEElementBase.elementList.length;) {
                    if (de.common.isChildOf(de.element.DEEElementBase.elementList[i].element, formatBody)) {
                        i++;
                    }
                    else {
                        de.element.DEEElementBase.elementList.splice(i, 1);
                    }
                }
                var _loop_6 = function (i) {
                    var htmlElement = htmlElements[i];
                    var deid = htmlElement.dataset.deid;
                    var dee = de.element.DEEElementBase.elementList.find(function (e) { return e.id == deid; });
                    if (dee) {
                        if (dee.element == htmlElement) {
                            // The DEE is this element. => Do nothing.
                        }
                        else {
                            // The item is Copied. => Make new element.
                            htmlElement.dataset.deid = de.common.newID();
                            loadElement(htmlElement);
                        }
                    }
                    else {
                        // The item is not loaded.
                        loadElement(htmlElement);
                    }
                };
                // Reset element's id
                for (var i = 0; i < htmlElements.length; i++) {
                    _loop_6(i);
                }
            }
            formatEditor.refreshElements = refreshElements;
            //#endregion
        })(formatEditor = de.formatEditor || (de.formatEditor = {}));
    })(de = ooo.de || (ooo.de = {}));
})(ooo || (ooo = {}));
var ooo;
(function (ooo) {
    var de;
    (function (de) {
        var formatEditor;
        (function (formatEditor) {
            function initStyleView() {
                var styleView = document.getElementById("styleView");
                var root = new de.element.DEEPropertyRoot(styleView, formatEditor.formatProperty);
                // Change Event
                var formatBody = document.getElementById("formatBody");
                formatBody.addEventListener("mouseup", function () {
                    onChangeSelection();
                });
                formatBody.addEventListener("keyup", function () {
                    onChangeSelection();
                });
                formatBody.addEventListener("paste", function () {
                    setTimeout(function () {
                        formatEditor.refreshElements();
                        arrangeTags();
                    }, 0);
                });
                formatBody.addEventListener("focus", function () {
                    arrangeTags();
                });
                formatBody.addEventListener("input", function () {
                    // input event.
                });
                formatBody.addEventListener("blur", function () {
                    arrangeTags();
                    keepSelection();
                });
                styleView.addEventListener("focus", reproduceSelection);
                showStyleProperty();
            }
            formatEditor.initStyleView = initStyleView;
            function onChangeSelection() {
                for (var name_3 in styleProperty) {
                    delete styleProperty[name_3];
                }
                stylePropertyRoot.resetValue();
                targetNodes = undefined;
            }
            var selectionInfo;
            function keepSelection() {
                var selection = getSelection();
                if (selection) {
                    var formatBody = document.getElementById("formatBody");
                    for (var i = 0; i < selection.rangeCount; i++) {
                        var range = selection.getRangeAt(i);
                        if (de.common.isChildOf(range.startContainer, formatBody) && de.common.isChildOf(range.endContainer, formatBody)) {
                            selectionInfo = {
                                startContainer: range.startContainer,
                                endContainer: range.endContainer,
                                startOffset: range.startOffset,
                                endOffset: range.endOffset
                            };
                            break;
                        }
                    }
                }
            }
            function reproduceSelection() {
                if (selectionInfo) {
                    var selection = window.getSelection();
                    var range = new Range();
                    range.setStart(selectionInfo.startContainer, selectionInfo.startOffset);
                    range.setEnd(selectionInfo.endContainer, selectionInfo.endOffset);
                    selection === null || selection === void 0 ? void 0 : selection.addRange(range);
                }
            }
            var stylePropertyRoot;
            var styleProperty = {};
            function showStyleProperty() {
                var styleView = document.getElementById("styleView");
                stylePropertyRoot = new de.element.DEEPropertyRoot(styleView, styleProperty);
                var prop_tag = new de.element.DEEPropertyItemSelect(stylePropertyRoot, "tag", [
                    { value: "span", caption: "Text", tooltip: "Document general text." },
                    { value: "h1", caption: "Title(Level 1)", tooltip: "Caption title." },
                    { value: "h2", caption: "Title(Level 2)", tooltip: "Section title." }
                ], "Text type", "", function (v) {
                    // TODO
                });
                function setStyleButton(style, parent, getValue) {
                    new de.element.DEEPropertyItemButton(parent, "Set", "", "", function () {
                        setStyle(style, getValue());
                    });
                    new de.element.DEEPropertyItemButton(parent, "Clear", "", "", function () {
                        setStyle(style, "");
                    });
                }
                var font = new de.element.DEEPropertyBox(stylePropertyRoot, "Font");
                // color
                var color = new de.element.DEEPropertyItemInput(font, "color", "Color", "Change font color.", undefined, "color");
                setStyleButton("color", font, function () {
                    return color.input.value;
                });
                // fontWeight
                var fontWeight = new de.element.DEEPropertyItemSelect(font, "fontWeight", [
                    "lighter", "normal", "bolder", "bold"
                ], "Width", "Change font width.");
                setStyleButton("fontWeight", font, function () {
                    return fontWeight.select.value;
                });
                // font size
                var fontSize = new de.element.DEEPropertyItemInput(font, "fontSize", "Size", "Change font size.", undefined, "number");
                font.getBody().append("px");
                setStyleButton("fontSize", font, function () {
                    return fontSize.input.value + "px";
                });
                // font style
                var fontStyle = new de.element.DEEPropertyItemSelect(font, "fontStyle", [
                    "normal", "italic", "oblique"
                ], "Style", "Change font style(italic/oblique).");
                setStyleButton("fontStyle", font, function () {
                    return fontStyle.select.value;
                });
                var background = new de.element.DEEPropertyBox(stylePropertyRoot, "Background");
                // background color
                var backgroundColor = new de.element.DEEPropertyItemInput(background, "backgroundColor", "Color", "Change background color.", undefined, "color");
                background.getBody().append(document.createElement("br"));
                setStyleButton("backgroundColor", background, function () {
                    return backgroundColor.input.value;
                });
                var textDecoration = new de.element.DEEPropertyBox(stylePropertyRoot, "Text line");
                // textdecoration line
                var textDecorationLine = new de.element.DEEPropertyItemSelect(textDecoration, "textDecorationLine", [
                    "none", "underline", "overline", "line-through", "blink"
                ], "Line type", "Change line type.");
                // textdecoration color
                var textDecorationColor = new de.element.DEEPropertyItemInput(textDecoration, "textDecorationColor", "Color", "Change line color.", undefined, "color");
                // textdecoration style
                var textDecorationStyle = new de.element.DEEPropertyItemSelect(textDecoration, "textDecorationStyle", [
                    "solid", "double", "dotted", "dashed", "wavy"
                ], "Line style", "Change line style.");
                // textdecoration thickness
                var textDecorationThickness = new de.element.DEEPropertyItemInput(textDecoration, "textDecorationThickness", "Thickness", "Change line thickness.", undefined, "number");
                textDecoration.getBody().append("px");
                textDecoration.getBody().append(document.createElement("br"));
                setStyleButton("textDecoration", textDecoration, function () {
                    var lineType = textDecorationLine.select.value;
                    var lineColor = textDecorationColor.input.value;
                    var lineStyle = textDecorationStyle.select.value;
                    var lineThickness = textDecorationThickness.input.value + "px";
                    return "".concat(lineType, " ").concat(lineColor, " ").concat(lineStyle, " ").concat(lineThickness);
                });
            }
            var targetStyle = [
                "color",
                "fontWeight",
                "fontFamily",
                "fontSize",
                "fontStyle",
                "background",
                "backgroundColor",
                "textDecoration",
                "textDecorationColor",
                "textDecorationLine",
            ];
            var targetTagName = [
                "SPAN", "U", "B", "I"
            ];
            function arrangeTags(target) {
                // Change Event
                var formatBody = document.getElementById("formatBody");
                function arrangeTagUnit(e) {
                    // remove if this is empty
                    if (isEmptyNode(e)) {
                        var parent_3 = e.parentNode;
                        if (parent_3) {
                            parent_3.removeChild(e);
                        }
                        return;
                    }
                    // arrange child
                    for (var i = 0; i < e.childNodes.length; i++) {
                        arrangeTagUnit(e.childNodes[i]);
                    }
                    for (var i = e.childNodes.length - 1; i >= 1; i--) {
                        // join sibling
                        if (compairSiblingStyle(e.childNodes[i - 1], e.childNodes[i])) {
                            joinSiblingElements(e.childNodes[i - 1], e.childNodes[i]);
                        }
                        // join to parent
                        if (e.childNodes.length == 1 && compairParentStyle(e)) {
                            joinParentElements(e.childNodes[0]);
                        }
                    }
                }
                function compairSiblingStyle(e1, e2) {
                    // Tag Check
                    if (!isTarget(e1) || !isTarget(e2)) {
                        return false;
                    }
                    // Style Check
                    var e1Style = getElementStyle(e1);
                    var e2Style = getElementStyle(e2);
                    for (var _i = 0, targetStyle_1 = targetStyle; _i < targetStyle_1.length; _i++) {
                        var styleName = targetStyle_1[_i];
                        if (e1Style[styleName] != e2Style[styleName]) {
                            return false;
                        }
                    }
                    return true;
                }
                function joinSiblingElements(e1, e2) {
                    var _a, _b, _c, _d;
                    var parent = e1.parentNode;
                    if (e1 instanceof Text) {
                        e1.textContent = removeDoubleNL(((_a = e1.textContent) !== null && _a !== void 0 ? _a : "") + ((_b = e2.textContent) !== null && _b !== void 0 ? _b : ""));
                        parent.removeChild(e2);
                    }
                    else if (e1 instanceof HTMLElement) {
                        e1.innerText = removeDoubleNL(((_c = e1.textContent) !== null && _c !== void 0 ? _c : "") + ((_d = e2.textContent) !== null && _d !== void 0 ? _d : ""));
                        parent.removeChild(e2);
                    }
                }
                function compairParentStyle(e) {
                    // It is possible only if Text or Span.
                    if (e instanceof Text) {
                        return true;
                    }
                    else if (e instanceof HTMLSpanElement) {
                        var e1Style = getElementStyle(e);
                        var e2Style = getElementStyle(e.parentElement);
                        for (var _i = 0, targetStyle_2 = targetStyle; _i < targetStyle_2.length; _i++) {
                            var styleName = targetStyle_2[_i];
                            // if the style is set, check the parent.
                            if (e1Style[styleName] != e2Style[styleName]) {
                                return false;
                            }
                        }
                        return true;
                    }
                    else {
                        return false;
                    }
                }
                function joinParentElements(e) {
                    var _a;
                    var parent = e.parentNode;
                    if (parent instanceof HTMLElement) {
                        parent.innerText = removeDoubleNL((_a = e.textContent) !== null && _a !== void 0 ? _a : "");
                    }
                }
                function removeDoubleNL(s) {
                    return s.replace(/[ \n][ \n]+/g, "\n");
                }
                function isEmptyNode(e) {
                    if (e instanceof Text) {
                        return e.textContent == "";
                    }
                    else if (e instanceof HTMLSpanElement) {
                        return e.innerText == "" && e.childElementCount == 0;
                    }
                    else {
                        return false;
                    }
                }
                arrangeTagUnit(target !== null && target !== void 0 ? target : formatBody);
            }
            function isTarget(e) {
                return e instanceof Text || (e instanceof HTMLElement && targetTagName.indexOf(e.tagName) >= 0);
            }
            function getElementStyle(e) {
                if (e instanceof Text) {
                    return getComputedStyle(e.parentElement);
                }
                else if (e instanceof HTMLElement) {
                    return getComputedStyle(e);
                }
                else {
                    console.log(e);
                    throw "Unknown Node";
                }
            }
            function setStyle(name, value) {
                for (var _i = 0, _a = getTargetNodes(); _i < _a.length; _i++) {
                    var target = _a[_i];
                    target.style[name] = value;
                }
            }
            var targetNodes;
            function getTargetNodes() {
                var _a, _b, _c, _d, _e, _f, _g, _h, _j, _k, _l;
                if (!selectionInfo) {
                    // check if selection is valid.
                    return [];
                }
                else if (targetNodes == undefined) {
                    // check if a range is selected
                    if (selectionInfo.startContainer == selectionInfo.endContainer && selectionInfo.startOffset == selectionInfo.endOffset) {
                        return [selectionInfo.startContainer.parentElement];
                    }
                    targetNodes = [];
                    // get parents of targets to change style
                    var targetParents_2 = [];
                    var addStartPos = function (node, start) {
                        var t = targetParents_2.find(function (v) { return v.node == node; });
                        if (!t) {
                            t = { node: node };
                            targetParents_2.push(t);
                        }
                        t.start = start;
                    };
                    var addEndPos = function (node, end) {
                        var t = targetParents_2.find(function (v) { return v.node == node; });
                        if (!t) {
                            t = { node: node };
                            targetParents_2.push(t);
                        }
                        t.end = end;
                    };
                    var getChildIndex = function (node) {
                        if (node.parentNode instanceof HTMLElement) {
                            for (var i = 0; i < node.parentNode.childNodes.length; i++) {
                                if (node == node.parentNode.childNodes[i]) {
                                    return i;
                                }
                            }
                        }
                        console.log("Unexpected.");
                        return -1;
                    };
                    // set start position
                    addStartPos(selectionInfo.startContainer, selectionInfo.startOffset);
                    for (var cur = selectionInfo.startContainer; cur.parentNode != null && !(cur instanceof HTMLBodyElement); cur = cur.parentNode) {
                        if (cur.parentNode instanceof HTMLElement) {
                            addStartPos(cur.parentNode, getChildIndex(cur));
                        }
                        else {
                            console.log("Unexpected.");
                        }
                    }
                    // set end position
                    addEndPos(selectionInfo.endContainer, selectionInfo.endOffset);
                    for (var cur = selectionInfo.endContainer; cur.parentNode != null && !(cur instanceof HTMLBodyElement); cur = cur.parentNode) {
                        if (cur.parentNode instanceof HTMLElement) {
                            addEndPos(cur.parentNode, getChildIndex(cur));
                        }
                        else {
                            console.log("Unexpected.");
                        }
                    }
                    // get target nodes
                    targetNodes = [];
                    for (var _i = 0, targetParents_1 = targetParents_2; _i < targetParents_1.length; _i++) {
                        var t = targetParents_1[_i];
                        if (t.node instanceof Text) {
                            if ((t.start == undefined || t.start == 0) && (t.end == undefined || t.end == ((_a = t.node.textContent) === null || _a === void 0 ? void 0 : _a.length))) {
                                var newSpan = de.common.insertTagBefore(t.node, "span");
                                newSpan.innerText = (_b = t.node.textContent) !== null && _b !== void 0 ? _b : "";
                                var parent_4 = t.node.parentNode;
                                if (parent_4) {
                                    parent_4.removeChild(t.node);
                                }
                                targetNodes.push(newSpan);
                            }
                            else if (t.end == undefined || t.end == ((_c = t.node.textContent) === null || _c === void 0 ? void 0 : _c.length)) {
                                var newSpan = de.common.insertTagAfter(t.node, "span");
                                var originalText = (_d = t.node.textContent) !== null && _d !== void 0 ? _d : "";
                                newSpan.innerText = originalText.substring(t.start);
                                t.node.textContent = originalText.substring(0, t.start);
                                targetNodes.push(newSpan);
                                selectionInfo.startContainer = newSpan.childNodes[0];
                                selectionInfo.startOffset = 0;
                            }
                            else if (t.start == undefined || t.start == 0) {
                                var newSpan = de.common.insertTagBefore(t.node, "span");
                                var originalText = (_e = t.node.textContent) !== null && _e !== void 0 ? _e : "";
                                newSpan.innerText = originalText.substring(0, t.end);
                                t.node.textContent = originalText.substring(t.end);
                                targetNodes.push(newSpan);
                                selectionInfo.endContainer = newSpan.childNodes[0];
                                selectionInfo.endOffset = (_g = (_f = newSpan.childNodes[0].textContent) === null || _f === void 0 ? void 0 : _f.length) !== null && _g !== void 0 ? _g : 0;
                            }
                            else {
                                var newSpan = de.common.insertTagAfter(t.node, "span");
                                var originalText = (_h = t.node.textContent) !== null && _h !== void 0 ? _h : "";
                                t.node.textContent = originalText.substring(0, t.start);
                                newSpan.innerText = originalText.substring(t.start, t.end);
                                newSpan.insertAdjacentText("afterend", originalText.substring(t.end));
                                targetNodes.push(newSpan);
                                selectionInfo.startContainer = newSpan.childNodes[0];
                                selectionInfo.startOffset = 0;
                                selectionInfo.endContainer = newSpan.childNodes[0];
                                selectionInfo.endOffset = (_k = (_j = newSpan.childNodes[0].textContent) === null || _j === void 0 ? void 0 : _j.length) !== null && _k !== void 0 ? _k : 0;
                            }
                        }
                        else if (t.node instanceof HTMLElement) {
                            var startPos = t.start == undefined ? 0 : t.start + 1;
                            var endPos = t.end == undefined ? t.node.childNodes.length : t.end;
                            for (var pos = startPos; pos < endPos; pos++) {
                                var child = t.node.childNodes[pos];
                                if (child instanceof Text) {
                                    var newSpan = de.common.insertTagAfter(child, "span");
                                    newSpan.innerText = (_l = child.textContent) !== null && _l !== void 0 ? _l : "";
                                    t.node.removeChild(child);
                                    targetNodes.push(newSpan);
                                }
                                else if (child instanceof HTMLElement) {
                                    targetNodes.push(child);
                                }
                                else {
                                    console.log("Unexpected");
                                }
                            }
                        }
                        else {
                            console.log("Unexpected");
                        }
                    }
                    return targetNodes;
                }
                else {
                    return targetNodes;
                }
            }
        })(formatEditor = de.formatEditor || (de.formatEditor = {}));
    })(de = ooo.de || (ooo.de = {}));
})(ooo || (ooo = {}));
//# sourceMappingURL=decc.js.map